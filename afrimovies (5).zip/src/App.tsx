import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { TranslatorsRow } from './components/TranslatorsRow';
import { MovieGrid } from './components/MovieGrid';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { SearchModal } from './components/SearchModal';
import { BottomNav } from './components/BottomNav';
import { FloatingActions } from './components/FloatingActions';
import { GetAppModal } from './components/GetAppModal';
import { JoinCommunityModal } from './components/JoinCommunityModal';
import { NavigationDrawer } from './components/NavigationDrawer';
import { RequestMovieModal } from './components/RequestMovieModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { StatusViewerModal } from './components/StatusViewerModal';
import { SeriesFolderView } from './components/SeriesFolderView';
import { AiVideoScanModal } from './components/AiVideoScanModal';
import { TRANSLATORS as initialTranslators, MOVIES as initialMovies, INITIAL_STATUSES } from './data/mockData';
import { Movie, NavTab, MovieStatus, Translator, TranslatorStatus, HeroSlide } from './types';
import { Play, ShieldCheck } from 'lucide-react';

const INITIAL_HERO_SLIDES: HeroSlide[] = [
  {
    id: 'age-of-adaline',
    title: 'AGE OF ADALINE',
    translatorName: 'ROCKY KIMO',
    description: 'Umugore umaze imyaka 80 atagira icyo ahindukaho cyangwa ngo asaze nyuma y\'impanuka y\'agatangaza. Rocky Kimomo abisobanura mu buryo bw\'agatangaza!',
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    category: 'Romance',
    rating: 4.8,
    year: 2024,
    type: 'Movie'
  },
  {
    id: 'major',
    title: 'MAJOR ACTION FORCE',
    translatorName: 'ROCKY KIMO',
    description: 'Ingabo idasanzwe irwanira igihugu mu buryo bw\'ubutwari n\'ishema. Rocky Kimo ayisobanura yikora ku mutima.',
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    category: 'Action',
    rating: 4.9,
    year: 2024,
    type: 'Movie'
  },
  {
    id: 'money-heist-agasobanuye',
    title: 'MONEY HEIST (AGASOBANUYE)',
    translatorName: 'VJ KABOSIO',
    description: 'Professor n\'itsinda rye ry\'abajura bagaba igitero ku banki nkuru. VJ Kabosio asobanura icyiciro ku cyiciro n\'amatsiko atagira urugero.',
    image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    category: 'Drama',
    rating: 4.95,
    year: 2023,
    type: 'Series'
  }
];

export default function App() {
  // Load movies from localStorage or initial mock data
  const [movies, setMovies] = useState<Movie[]>(() => {
    try {
      const saved = localStorage.getItem('cineva_movies_v2');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load saved movies', e);
    }
    return initialMovies;
  });

  // Load custom Hero Banners / Slides state from localStorage or initial
  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>(() => {
    try {
      const saved = localStorage.getItem('afrimovies_hero_slides');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load saved hero slides', e);
    }
    return INITIAL_HERO_SLIDES;
  });

  // Load translators state from localStorage or initial
  const [translators, setTranslators] = useState<Translator[]>(() => {
    try {
      const saved = localStorage.getItem('cineva_translators_v2');
      if (saved) {
        const parsed: Translator[] = JSON.parse(saved);
        // Ensure B THE GREAT and default translators are present
        const existingIds = new Set(parsed.map(t => t.id.toLowerCase()));
        const missing = initialTranslators.filter(t => !existingIds.has(t.id.toLowerCase()));
        return [...parsed, ...missing];
      }
    } catch (e) {
      console.error('Failed to load saved translators', e);
    }
    return initialTranslators;
  });

  // Load status videos state from localStorage or initial mock
  const [statuses, setStatuses] = useState<TranslatorStatus[]>(() => {
    try {
      const saved = localStorage.getItem('cineva_statuses_v2');
      if (saved) {
        const parsed: TranslatorStatus[] = JSON.parse(saved);
        // Filter out expired statuses (> 24 hours)
        return parsed.filter(s => s.expiresAt > Date.now());
      }
    } catch (e) {
      console.error('Failed to load saved statuses', e);
    }
    return INITIAL_STATUSES;
  });

  // Load WhatsApp Link state from localStorage or default
  const [whatsappLink, setWhatsappLink] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('afrimovies_whatsapp_link');
      if (saved) return saved;
    } catch (e) {
      console.error('Failed to load whatsapp link', e);
    }
    return 'https://chat.whatsapp.com/afrimovies-official-community';
  });

  // Load WhatsApp Request Phone Number state from localStorage or default
  const [requestWhatsappNumber, setRequestWhatsappNumber] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('afrimovies_request_whatsapp_number');
      if (saved) return saved;
    } catch (e) {
      console.error('Failed to load request whatsapp number', e);
    }
    return '250780000000';
  });

  // Load Download Controller (ON / OFF) state from localStorage or default true
  const [isDownloadsEnabled, setIsDownloadsEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('afrimovies_downloads_enabled');
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to load downloads enabled state', e);
    }
    return true;
  });

  // Save state updates to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('afrimovies_downloads_enabled', JSON.stringify(isDownloadsEnabled));
    } catch (e) {
      console.error('Failed to save downloads enabled state', e);
    }
  }, [isDownloadsEnabled]);

  // Save state updates to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('cineva_movies_v2', JSON.stringify(movies));
    } catch (e) {
      console.error('Failed to save movies', e);
    }
  }, [movies]);

  useEffect(() => {
    try {
      localStorage.setItem('cineva_translators_v2', JSON.stringify(translators));
    } catch (e) {
      console.error('Failed to save translators', e);
    }
  }, [translators]);

  useEffect(() => {
    try {
      localStorage.setItem('cineva_statuses_v2', JSON.stringify(statuses));
    } catch (e) {
      console.error('Failed to save statuses', e);
    }
  }, [statuses]);

  useEffect(() => {
    try {
      localStorage.setItem('afrimovies_whatsapp_link', whatsappLink);
    } catch (e) {
      console.error('Failed to save whatsapp link', e);
    }
  }, [whatsappLink]);

  useEffect(() => {
    try {
      localStorage.setItem('afrimovies_hero_slides', JSON.stringify(heroSlides));
    } catch (e) {
      console.error('Failed to save hero slides', e);
    }
  }, [heroSlides]);

  // Selected state
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [selectedTranslatorId, setSelectedTranslatorId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<NavTab>('home');

  // Status Viewer state
  const [viewingStatusTranslatorId, setViewingStatusTranslatorId] = useState<string | null>(null);

  // Modals state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isGetAppOpen, setIsGetAppOpen] = useState(false);
  const [isJoinCommunityOpen, setIsJoinCommunityOpen] = useState(false);
  const [isRequestMovieOpen, setIsRequestMovieOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAiScanOpen, setIsAiScanOpen] = useState(false);

  // Hero Slides Handlers
  const handleAddHeroSlide = (newSlide: HeroSlide) => {
    setHeroSlides(prev => [newSlide, ...prev]);
  };

  const handleDeleteHeroSlide = (slideId: string) => {
    setHeroSlides(prev => prev.filter(s => s.id !== slideId));
  };

  const handleUpdateHeroSlide = (updatedSlide: HeroSlide) => {
    setHeroSlides(prev => prev.map(s => (s.id === updatedSlide.id ? updatedSlide : s)));
  };

  // Admin Actions
  const handleAddMovie = (newMovie: Movie) => {
    setMovies(prev => [newMovie, ...prev]);
  };

  const handleUpdateMovie = (updatedMovie: Movie) => {
    setMovies(prev => prev.map(m => (m.id === updatedMovie.id ? updatedMovie : m)));
  };

  const handleBatchAddMovies = (newMovies: Movie[]) => {
    setMovies(prev => [...newMovies, ...prev]);
  };

  const handleDeleteMovie = (movieId: string) => {
    setMovies(prev => prev.filter(m => m.id !== movieId));
  };

  const handleUpdateMovieStatus = (movieId: string, newStatus: MovieStatus) => {
    setMovies(prev =>
      prev.map(m => (m.id === movieId ? { ...m, status: newStatus } : m))
    );
  };

  const handleUpdateTranslators = (updatedTranslators: Translator[]) => {
    setTranslators(updatedTranslators);
  };

  const handleAddStatus = (newStatus: TranslatorStatus) => {
    setStatuses(prev => [newStatus, ...prev]);
  };

  const handleDeleteStatus = (statusId: string) => {
    setStatuses(prev => prev.filter(s => s.id !== statusId));
  };

  const handleUpdateWhatsappLink = (newLink: string) => {
    setWhatsappLink(newLink);
  };

  const handleUpdateRequestWhatsappNumber = (num: string) => {
    const clean = num.trim();
    setRequestWhatsappNumber(clean);
    try {
      localStorage.setItem('afrimovies_request_whatsapp_number', clean);
    } catch (e) {
      console.error('Failed to save request whatsapp number', e);
    }
  };

  // Filter active statuses for the currently selected status viewer translator
  const activeStatusesForViewer = viewingStatusTranslatorId
    ? statuses.filter(s => s.translatorId === viewingStatusTranslatorId && s.expiresAt > Date.now())
    : [];

  // Filter movies by selected translator and current tab
  const filteredMovies = movies.filter((m) => {
    // Translator filter
    if (selectedTranslatorId && m.translatorId !== selectedTranslatorId) {
      return false;
    }

    // Tab filter
    if (activeTab === 'series') {
      return m.type === 'Series';
    } else if (activeTab === 'dub') {
      return true; // all dubbed movies
    }

    return true;
  });

  const featuredMovies = movies.filter((m) => m.isFeatured || m.isLatest || m.status === 'NEW');

  const selectedTranslatorObj = translators.find((t) => t.id === selectedTranslatorId);

  return (
    <div className="min-h-screen bg-[#0a0f16] text-gray-100 font-sans selection:bg-emerald-500 selection:text-black pb-20 sm:pb-12">
      
      {/* Top Header Bar */}
      <Header
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenMenu={() => setIsMenuOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenAiScan={() => setIsAiScanOpen(true)}
        activeTranslatorName={selectedTranslatorObj ? selectedTranslatorObj.name : null}
        onClearTranslatorFilter={() => setSelectedTranslatorId(null)}
      />

      <main>
        {/* If All Series tab is selected, render Series Folder View */}
        {activeTab === 'all_series' ? (
          <SeriesFolderView
            movies={movies}
            onSelectMovie={(movie) => setSelectedMovie(movie)}
            onBackToHome={() => setActiveTab('home')}
            downloadsEnabled={isDownloadsEnabled}
          />
        ) : (
          <>
            {/* Featured Hero Banner */}
            <HeroBanner
              featuredMovies={featuredMovies.length > 0 ? featuredMovies : movies}
              heroSlides={heroSlides}
              onSelectMovie={(movie) => setSelectedMovie(movie)}
            />

            {/* OUR TRANSLATORS • LIVE Row matching screenshot with Status support */}
            <TranslatorsRow
              translators={translators}
              statuses={statuses}
              selectedTranslatorId={selectedTranslatorId}
              onSelectTranslator={(id) => setSelectedTranslatorId(id)}
              onOpenStatus={(translatorId) => setViewingStatusTranslatorId(translatorId)}
            />

            {/* LATEST RELEASES & CATEGORIZED SECTIONS */}
            <MovieGrid
              movies={filteredMovies}
              onSelectMovie={(movie) => setSelectedMovie(movie)}
              activeCategory={activeCategory}
              onChangeCategory={(cat) => setActiveCategory(cat)}
              activeTranslatorName={selectedTranslatorObj ? selectedTranslatorObj.name : null}
              downloadsEnabled={isDownloadsEnabled}
              onSelectSeriesFolderView={() => setActiveTab('all_series')}
            />
          </>
        )}
      </main>

      {/* Footer info section */}
      <footer className="border-t border-emerald-950/80 bg-[#080d14] py-8 px-4 mt-12 text-center text-xs text-gray-400">
        <div className="max-w-7xl mx-auto flex flex-col items-center justify-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-emerald-500 text-black flex items-center justify-center font-bold text-xs">
              <Play className="w-3.5 h-3.5 fill-black" />
            </div>
            <span className="font-extrabold text-white tracking-widest text-sm uppercase">AFRIMOVIES</span>
          </div>
          <p className="max-w-md text-gray-400 leading-relaxed">
            Ihuriro rya mbere mu Rwanda ryo kureberaho agasobanuye gaharaye ka Rocky Kimomo, VJ Kabosio, Sankara, Hakim n'abandi basobanuzi.
          </p>
          <div className="flex items-center gap-4 text-emerald-400 font-semibold pt-2">
            <button onClick={() => setIsAdminOpen(true)} className="hover:underline text-emerald-300 flex items-center gap-1 font-bold">
              <ShieldCheck className="w-3.5 h-3.5" /> Admin Dashboard
            </button>
            <span>•</span>
            <button onClick={() => setIsJoinCommunityOpen(true)} className="hover:underline">Join WhatsApp</button>
            <span>•</span>
            <button onClick={() => setIsRequestMovieOpen(true)} className="hover:underline">Saba Filime</button>
          </div>
          <p className="text-gray-600 text-[11px] pt-2">
            © {new Date().getFullYear()} AfriMovies Premium Streaming Platform. All rights reserved.
          </p>
        </div>
      </footer>

      {/* Floating Button: Join Us */}
      <FloatingActions
        onOpenGetApp={() => setIsGetAppOpen(true)}
        onOpenJoinCommunity={() => setIsJoinCommunityOpen(true)}
      />

      {/* Mobile Bottom Navigation Bar matching exact screenshot tabs */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={(tab) => setActiveTab(tab)}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* 24-Hour WhatsApp-like Status Viewer Modal */}
      {viewingStatusTranslatorId && activeStatusesForViewer.length > 0 && (
        <StatusViewerModal
          isOpen={!!viewingStatusTranslatorId}
          onClose={() => setViewingStatusTranslatorId(null)}
          statuses={activeStatusesForViewer}
        />
      )}

      {/* Video Player Modal */}
      {selectedMovie && (
        <VideoPlayerModal
          movie={selectedMovie}
          onClose={() => setSelectedMovie(null)}
          onOpenGetApp={() => setIsGetAppOpen(true)}
          downloadsEnabled={isDownloadsEnabled}
          allMovies={movies}
          onSelectMovie={(movie) => setSelectedMovie(movie)}
        />
      )}

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        movies={movies}
        translators={translators}
        onSelectMovie={(movie) => setSelectedMovie(movie)}
      />

      {/* Navigation Drawer */}
      <NavigationDrawer
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onSelectTab={(tab) => setActiveTab(tab)}
        onOpenGetApp={() => setIsGetAppOpen(true)}
        onOpenJoinCommunity={() => setIsJoinCommunityOpen(true)}
        onRequestMovie={() => setIsRequestMovieOpen(true)}
        onOpenAiScan={() => setIsAiScanOpen(true)}
      />

      {/* AI Video Scan Modal */}
      <AiVideoScanModal
        isOpen={isAiScanOpen}
        onClose={() => setIsAiScanOpen(false)}
        movies={movies}
        onSelectMovie={(movie) => setSelectedMovie(movie)}
        onRequestMovie={(suggestedTitle) => {
          setIsRequestMovieOpen(true);
        }}
      />

      {/* Admin Panel Modal */}
      <AdminPanelModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        movies={movies}
        translators={translators}
        statuses={statuses}
        heroSlides={heroSlides}
        onAddHeroSlide={handleAddHeroSlide}
        onDeleteHeroSlide={handleDeleteHeroSlide}
        onUpdateHeroSlide={handleUpdateHeroSlide}
        whatsappLink={whatsappLink}
        onUpdateWhatsappLink={handleUpdateWhatsappLink}
        requestWhatsappNumber={requestWhatsappNumber}
        onUpdateRequestWhatsappNumber={handleUpdateRequestWhatsappNumber}
        downloadsEnabled={isDownloadsEnabled}
        onToggleDownloads={setIsDownloadsEnabled}
        onAddMovie={handleAddMovie}
        onUpdateMovie={handleUpdateMovie}
        onDeleteMovie={handleDeleteMovie}
        onUpdateMovieStatus={handleUpdateMovieStatus}
        onUpdateTranslators={handleUpdateTranslators}
        onAddStatus={handleAddStatus}
        onDeleteStatus={handleDeleteStatus}
        onBatchAddMovies={handleBatchAddMovies}
      />

      {/* Get App APK Download Modal */}
      <GetAppModal
        isOpen={isGetAppOpen}
        onClose={() => setIsGetAppOpen(false)}
      />

      {/* Join Community Modal */}
      <JoinCommunityModal
        isOpen={isJoinCommunityOpen}
        onClose={() => setIsJoinCommunityOpen(false)}
        whatsappLink={whatsappLink}
      />

      {/* Request Movie Modal */}
      <RequestMovieModal
        isOpen={isRequestMovieOpen}
        onClose={() => setIsRequestMovieOpen(false)}
        requestWhatsappNumber={requestWhatsappNumber}
      />

    </div>
  );
}
