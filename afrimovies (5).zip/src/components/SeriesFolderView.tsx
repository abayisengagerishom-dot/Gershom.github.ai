import React, { useState } from 'react';
import { Movie, Episode } from '../types';
import { Folder, Tv, Play, Download, Search, Film, ArrowLeft, ChevronRight, Layers } from 'lucide-react';

interface SeriesFolderViewProps {
  movies: Movie[];
  onSelectMovie: (movie: Movie) => void;
  onBackToHome: () => void;
  downloadsEnabled?: boolean;
}

interface SeriesFolderItem {
  id: string;
  title: string;
  section: 'Korea Series' | 'American Series' | 'Agasobanuye Series' | 'Chinese & Asian Series';
  episodesCount: number;
  translatorName: string;
  poster: string;
  description: string;
  year: number;
  movieRef?: Movie;
  episodesList?: Episode[];
}

export const SeriesFolderView: React.FC<SeriesFolderViewProps> = ({
  movies,
  onSelectMovie,
  onBackToHome,
  downloadsEnabled = true
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<SeriesFolderItem | null>(null);

  // Default curated series folders matching user request (CITY HUNT ep 20 in Korea, ALL AMERICAN ep 16 in American)
  const defaultSeriesFolders: SeriesFolderItem[] = [
    {
      id: 'folder-city-hunt',
      title: 'CITY HUNT',
      section: 'Korea Series',
      episodesCount: 20,
      translatorName: 'VJ Kabosio',
      poster: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&q=80',
      description: 'Filime y\'ubwoba n\'intambara idasanzwe yo muri Korea ihagarariwe na VJ Kabosio.',
      year: 2024,
      episodesList: Array.from({ length: 20 }, (_, i) => ({
        id: `city-hunt-ep-${i + 1}`,
        number: i + 1,
        title: `CITY HUNT - Ep ${i + 1}`,
        duration: '45 mins',
        thumbnail: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=400&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
      }))
    },
    {
      id: 'folder-all-american',
      title: 'ALL AMERICAN',
      section: 'American Series',
      episodesCount: 16,
      translatorName: 'VJ Gaheza',
      poster: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?auto=format&fit=crop&w=600&q=80',
      description: 'Injyana y\'umupira n\'ubuzima bwa Beverly Hills na South LA isobanuwe na VJ Gaheza.',
      year: 2024,
      episodesList: Array.from({ length: 16 }, (_, i) => ({
        id: `all-american-ep-${i + 1}`,
        number: i + 1,
        title: `ALL AMERICAN - Ep ${i + 1}`,
        duration: '42 mins',
        thumbnail: 'https://images.unsplash.com/photo-1517649763962-0c623266ddc0?auto=format&fit=crop&w=400&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'
      }))
    },
    {
      id: 'folder-squid-game',
      title: 'SQUID GAME',
      section: 'Korea Series',
      episodesCount: 18,
      translatorName: 'VJ Junior',
      poster: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&w=600&q=80',
      description: 'Imikino y\'urupfu n\'amafaranga menshi muri Korea isobanuwe na VJ Junior.',
      year: 2024,
      episodesList: Array.from({ length: 18 }, (_, i) => ({
        id: `squid-game-ep-${i + 1}`,
        number: i + 1,
        title: `SQUID GAME - Ep ${i + 1}`,
        duration: '50 mins',
        thumbnail: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&w=400&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
      }))
    },
    {
      id: 'folder-money-heist',
      title: 'MONEY HEIST (LA CASA DE PAPEL)',
      section: 'American Series',
      episodesCount: 24,
      translatorName: 'Rocky Kimo',
      poster: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80',
      description: 'Wiba banki nk\'ingabo za Professor. Agasobanuye ka Rocky Kimo.',
      year: 2023,
      episodesList: Array.from({ length: 24 }, (_, i) => ({
        id: `money-heist-ep-${i + 1}`,
        number: i + 1,
        title: `MONEY HEIST - Ep ${i + 1}`,
        duration: '48 mins',
        thumbnail: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=400&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4'
      }))
    },
    {
      id: 'folder-kingdom',
      title: 'KINGDOM OF ZOMBIES',
      section: 'Agasobanuye Series',
      episodesCount: 12,
      translatorName: 'Sankara',
      poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&q=80',
      description: 'Amateka y\'intambara y\'ikoreshwa ry\'ingoma muri Joseon na VJ Sankara.',
      year: 2024,
      episodesList: Array.from({ length: 12 }, (_, i) => ({
        id: `kingdom-ep-${i + 1}`,
        number: i + 1,
        title: `KINGDOM OF ZOMBIES - Ep ${i + 1}`,
        duration: '55 mins',
        thumbnail: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&q=80',
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4'
      }))
    }
  ];

  // Derive extra series uploaded from backend/movies state
  const uploadedSeries = movies
    .filter(m => m.type === 'Series' || m.category === 'Series')
    .map((m) => ({
      id: `folder-uploaded-${m.id}`,
      title: m.title.toUpperCase(),
      section: (m.category.includes('Korea') ? 'Korea Series' : m.category.includes('America') ? 'American Series' : 'Agasobanuye Series') as any,
      episodesCount: m.episodes?.length || 12,
      translatorName: m.translatorName,
      poster: m.poster,
      description: m.description,
      year: m.year,
      movieRef: m,
      episodesList: m.episodes || Array.from({ length: 10 }, (_, i) => ({
        id: `${m.id}-ep-${i + 1}`,
        number: i + 1,
        title: `${m.title} - Ep ${i + 1}`,
        duration: '45 mins',
        thumbnail: m.poster,
        videoUrl: m.videoUrl
      }))
    }));

  const allFolders = [...defaultSeriesFolders, ...uploadedSeries.filter(u => !defaultSeriesFolders.some(d => d.title === u.title))];

  const filteredFolders = allFolders.filter(f => 
    f.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    f.translatorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    f.section.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const sectionsList: Array<'Korea Series' | 'American Series' | 'Agasobanuye Series' | 'Chinese & Asian Series'> = [
    'Korea Series',
    'American Series',
    'Agasobanuye Series',
    'Chinese & Asian Series'
  ];

  const handleDownloadEp = (folderTitle: string, epNum: number, url: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = url || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
    link.download = `${folderTitle}_Ep_${epNum}.mp4`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 animate-fade-in text-white min-h-[80vh]">
      
      {/* Top Breadcrumb Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8 border-b border-cyan-950/80 pb-5">
        <div className="flex items-center gap-3">
          <button
            onClick={() => selectedFolder ? setSelectedFolder(null) : onBackToHome()}
            className="w-10 h-10 rounded-xl bg-cyan-950/80 hover:bg-cyan-400 hover:text-black border border-cyan-500/40 text-cyan-400 flex items-center justify-center transition-all shadow-md"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div>
            <div className="flex items-center gap-2">
              <Folder className="w-6 h-6 text-cyan-400" />
              <h1 className="text-2xl font-black text-white uppercase tracking-wider font-mono">
                {selectedFolder ? selectedFolder.title : 'ALL SERIES FOLDERS'}
              </h1>
            </div>
            <p className="text-xs text-cyan-400 font-semibold tracking-wide">
              {selectedFolder ? `${selectedFolder.section} • ${selectedFolder.episodesCount} Episodes` : 'Shakisha folder y\'aserie ushaka Kureba no Kuvisohora'}
            </p>
          </div>
        </div>

        {/* Search Input inside All Series */}
        {!selectedFolder && (
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              placeholder="Shaka folder ya serie..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#111823] border border-cyan-900/60 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400 shadow-inner"
            />
            <Search className="w-4 h-4 text-cyan-400 absolute left-3.5 top-3" />
          </div>
        )}
      </div>

      {/* SINGLE FOLDER EXPANDED VIEW */}
      {selectedFolder ? (
        <div className="space-y-6">
          {/* Folder Hero Banner */}
          <div className="relative rounded-3xl overflow-hidden bg-[#111823] border border-cyan-900/60 p-6 flex flex-col md:flex-row items-center gap-6 shadow-2xl">
            <img
              src={selectedFolder.poster}
              alt={selectedFolder.title}
              className="w-40 h-56 object-cover rounded-2xl shadow-xl border border-cyan-500/30"
            />
            <div className="flex-1 space-y-3 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-black bg-cyan-400 text-black uppercase">
                  {selectedFolder.section}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-black/60 text-cyan-300 border border-cyan-500/40">
                  {selectedFolder.episodesCount} Episodes
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-white font-mono uppercase tracking-wide">
                {selectedFolder.title}
              </h2>

              <p className="text-xs sm:text-sm text-gray-300 max-w-2xl">
                {selectedFolder.description}
              </p>

              <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start gap-3">
                <span className="text-xs text-cyan-400 font-extrabold">
                  Agasobanuye by: <strong className="text-white">{selectedFolder.translatorName}</strong>
                </span>
                <span>•</span>
                <span className="text-xs text-gray-400 font-semibold">{selectedFolder.year}</span>
              </div>
            </div>
          </div>

          {/* Episodes Grid in Folder */}
          <div className="space-y-4">
            <h3 className="text-lg font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-5 h-5 text-cyan-400" />
              Ibyiciro by'Amasepisode (Episodes List)
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {selectedFolder.episodesList?.map((ep) => (
                <div
                  key={ep.id}
                  className="bg-[#111823] hover:bg-[#16202e] border border-cyan-950/60 hover:border-cyan-500/50 rounded-2xl p-3.5 flex items-center justify-between gap-3 transition-all group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="relative w-16 h-12 rounded-xl overflow-hidden bg-black flex-shrink-0 border border-cyan-900/40">
                      <img src={ep.thumbnail} alt={ep.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <Play className="w-4 h-4 text-cyan-400 fill-cyan-400" />
                      </div>
                    </div>

                    <div className="min-w-0">
                      <h4 className="text-xs font-extrabold text-white truncate group-hover:text-cyan-400 transition-colors">
                        {ep.title}
                      </h4>
                      <p className="text-[10px] text-cyan-400 font-medium">
                        Episode {ep.number} • {ep.duration}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button
                      onClick={() => {
                        const targetMovie: Movie = selectedFolder.movieRef ? {
                          ...selectedFolder.movieRef,
                          episodes: selectedFolder.episodesList
                        } : {
                          id: selectedFolder.id,
                          title: selectedFolder.title,
                          category: selectedFolder.section,
                          translatorName: selectedFolder.translatorName,
                          poster: selectedFolder.poster,
                          videoUrl: ep.videoUrl,
                          description: selectedFolder.description,
                          type: 'Series',
                          year: selectedFolder.year,
                          status: 'NEW',
                          rating: 4.9,
                          views: '12.4k',
                          episodes: selectedFolder.episodesList
                        };

                        // Put the clicked episode first so VideoPlayerModal opens directly on it
                        if (targetMovie.episodes) {
                          const reorderedEps = [ep, ...targetMovie.episodes.filter(e => e.id !== ep.id)];
                          targetMovie.episodes = reorderedEps;
                          targetMovie.videoUrl = ep.videoUrl;
                        }

                        onSelectMovie(targetMovie);
                      }}
                      className="p-2 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-400 hover:brightness-110 text-black font-extrabold text-xs transition-all shadow-md"
                      title="Play episode"
                    >
                      <Play className="w-3.5 h-3.5 fill-black" />
                    </button>

                    {downloadsEnabled && (
                      <button
                        onClick={(e) => handleDownloadEp(selectedFolder.title, ep.number, ep.videoUrl, e)}
                        className="p-2 rounded-xl bg-cyan-950/80 hover:bg-cyan-400 text-cyan-400 hover:text-black border border-cyan-500/30 transition-all"
                        title="Download episode"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* ALL SERIES SECTIONS OVERVIEW */
        <div className="space-y-10">
          {sectionsList.map((sec) => {
            const secFolders = filteredFolders.filter(f => f.section === sec);
            if (secFolders.length === 0) return null;

            return (
              <section key={sec} className="space-y-4">
                {/* Section Title Banner */}
                <div className="flex items-center justify-between border-l-4 border-cyan-400 pl-3">
                  <div>
                    <h2 className="text-xl sm:text-2xl font-extrabold text-white uppercase tracking-wider">
                      {sec}
                    </h2>
                    <p className="text-xs text-cyan-400 font-medium">
                      Folders y'amaserie yo muri {sec}
                    </p>
                  </div>

                  <span className="text-xs font-bold text-gray-400 bg-[#111823] px-3 py-1 rounded-full border border-cyan-950/60">
                    {secFolders.length} Folders
                  </span>
                </div>

                {/* Grid of Series Folders */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                  {secFolders.map((f) => (
                    <div
                      key={f.id}
                      onClick={() => setSelectedFolder(f)}
                      className="group relative bg-[#111823] hover:bg-[#16202e] border border-cyan-950/80 hover:border-cyan-500/60 rounded-3xl overflow-hidden transition-all duration-300 cursor-pointer p-4 flex flex-col justify-between hover:-translate-y-1 shadow-xl hover:shadow-cyan-950/50"
                    >
                      {/* Top Folder Icon Badge Header */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center group-hover:bg-cyan-400 group-hover:text-black transition-all">
                          <Folder className="w-5 h-5 fill-current" />
                        </div>

                        <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-cyan-400 text-black tracking-tight shadow-md">
                          ep {f.episodesCount}
                        </span>
                      </div>

                      {/* Poster Preview */}
                      <div className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden mb-3 bg-[#0a0f16]">
                        <img
                          src={f.poster}
                          alt={f.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                        
                        <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                          <span className="text-[10px] font-extrabold text-cyan-300 bg-black/60 px-2 py-0.5 rounded-md backdrop-blur-md">
                            {f.translatorName}
                          </span>
                          <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>

                      {/* Folder Title */}
                      <div>
                        <h3 className="text-sm font-extrabold text-white group-hover:text-cyan-400 transition-colors uppercase font-mono tracking-wide line-clamp-1">
                          {f.title}
                        </h3>
                        <p className="text-[11px] text-gray-400 mt-1 line-clamp-1">
                          {f.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}

    </div>
  );
};
