import React, { useState, useEffect } from 'react';
import { MessageCircle, ArrowUp } from 'lucide-react';

interface FloatingActionsProps {
  onOpenJoinCommunity: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({
  onOpenJoinCommunity
}) => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-20 sm:bottom-8 right-4 z-30 flex flex-col items-end gap-2.5 pointer-events-none">
      
      {/* Join Us WhatsApp Button */}
      <button
        onClick={onOpenJoinCommunity}
        className="pointer-events-auto px-4.5 py-3 rounded-2xl bg-[#00E676] hover:bg-[#1cd968] text-black font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-xl shadow-emerald-500/40 hover:scale-105 active:scale-95 transition-all animate-bounce-short"
      >
        <MessageCircle className="w-4 h-4 stroke-[2.5]" />
        <span>Join Us</span>
      </button>

      {/* Scroll to Top Circle Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="pointer-events-auto w-10 h-10 rounded-full bg-[#00E676] hover:bg-emerald-400 text-black flex items-center justify-center shadow-lg shadow-emerald-500/40 hover:scale-110 active:scale-95 transition-all"
          aria-label="Scroll to top"
        >
          <ArrowUp className="w-5 h-5 stroke-[2.5]" />
        </button>
      )}

    </div>
  );
};
