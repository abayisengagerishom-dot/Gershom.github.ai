import React from 'react';

interface VLCLogoProps {
  className?: string;
  size?: number;
}

export const VLCLogo: React.FC<VLCLogoProps> = ({ className = "w-7 h-7", size }) => {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      width={size}
      height={size}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="vlc-orange-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FF8000" />
          <stop offset="50%" stopColor="#FF5500" />
          <stop offset="100%" stopColor="#D93D00" />
        </linearGradient>
        <linearGradient id="vlc-white-grad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="100%" stopColor="#E0E0E0" />
        </linearGradient>
        <linearGradient id="vlc-base-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#333333" />
          <stop offset="100%" stopColor="#111111" />
        </linearGradient>
      </defs>

      {/* Base */}
      <ellipse cx="50" cy="88" rx="42" ry="10" fill="url(#vlc-base-grad)" />
      <ellipse cx="50" cy="85" rx="38" ry="8" fill="url(#vlc-orange-grad)" />

      {/* Outer Cone Body */}
      <path
        d="M 50 10 
           L 18 84 
           A 32 6 0 0 0 82 84 
           Z"
        fill="url(#vlc-orange-grad)"
      />

      {/* Lower White Band */}
      <path
        d="M 28 62 
           L 72 62 
           L 77 74 
           A 30 5 0 0 1 23 74 
           Z"
        fill="url(#vlc-white-grad)"
      />

      {/* Upper White Band */}
      <path
        d="M 38 38 
           L 62 38 
           L 67 50 
           A 20 4 0 0 1 33 50 
           Z"
        fill="url(#vlc-white-grad)"
      />

      {/* Top Cap Ring */}
      <ellipse cx="50" cy="12" rx="5" ry="3" fill="#FFAA33" />
    </svg>
  );
};
