import React from 'react';
import { Translator, TranslatorStatus } from '../types';
import { Radio, Play, Sparkles } from 'lucide-react';

interface TranslatorsRowProps {
  translators: Translator[];
  statuses?: TranslatorStatus[];
  selectedTranslatorId: string | null;
  onSelectTranslator: (id: string | null) => void;
  onOpenStatus?: (translatorId: string) => void;
  onViewTranslatorProfile?: (translator: Translator) => void;
}

export const TranslatorsRow: React.FC<TranslatorsRowProps> = ({
  translators,
  statuses = [],
  selectedTranslatorId,
  onSelectTranslator,
  onOpenStatus,
  onViewTranslatorProfile
}) => {
  // Helper to check if translator has unexpired status video
  const hasActiveStatus = (translatorId: string) => {
    return statuses.some(s => s.translatorId === translatorId && s.expiresAt > Date.now());
  };

  return (
    <section className="py-6 px-4 max-w-7xl mx-auto">
      {/* Section Header matching exact CINEVA layout */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-3">
          {/* Green bar accent matching screenshot */}
          <div className="w-1.5 h-6 bg-emerald-400 rounded-full" />
          
          <h2 className="text-lg sm:text-xl font-black text-white uppercase tracking-wider font-sans">
            OUR TRANSLATORS
          </h2>

          {/* LIVE status pill badge */}
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 uppercase tracking-widest animate-pulse">
            <Radio className="w-3 h-3 text-emerald-400" /> LIVE
          </span>
        </div>

        {selectedTranslatorId && (
          <button
            onClick={() => onSelectTranslator(null)}
            className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 underline underline-offset-4"
          >
            Show All
          </button>
        )}
      </div>

      {/* Horizontal Scrollable Container */}
      <div className="flex items-center gap-5 overflow-x-auto pb-4 scrollbar-none scroll-smooth">
        {translators.map((t) => {
          const isSelected = selectedTranslatorId === t.id;
          const activeStatuses = statuses.filter(s => s.translatorId === t.id && s.expiresAt > Date.now());
          const statusCount = activeStatuses.length;
          const isStatusActive = statusCount > 0;

          return (
            <div
              key={t.id}
              onClick={() => {
                if (isStatusActive && onOpenStatus) {
                  onOpenStatus(t.id);
                } else {
                  if (isSelected) {
                    onSelectTranslator(null);
                  } else {
                    onSelectTranslator(t.id);
                    if (onViewTranslatorProfile) onViewTranslatorProfile(t);
                  }
                }
              }}
              className="flex flex-col items-center flex-shrink-0 cursor-pointer group"
            >
              {/* Circular Avatar Container with Green Glowing Ring */}
              <div className="relative mb-2">
                <div
                  className={`w-20 h-20 sm:w-24 sm:h-24 rounded-full p-[3px] transition-all duration-300 ${
                    isStatusActive
                      ? 'bg-gradient-to-tr from-emerald-400 via-green-300 to-emerald-500 shadow-xl shadow-emerald-500/50 scale-105 ring-4 ring-emerald-400/60 animate-pulse'
                      : isSelected
                      ? 'bg-gradient-to-tr from-emerald-400 via-emerald-300 to-green-500 shadow-xl shadow-emerald-500/40 scale-105 ring-4 ring-emerald-500/30'
                      : 'bg-emerald-500/80 hover:bg-emerald-400 group-hover:scale-105 shadow-md shadow-emerald-950/50'
                  }`}
                >
                  <div className="w-full h-full rounded-full overflow-hidden bg-[#131b26] relative">
                    <img
                      src={t.avatar}
                      alt={t.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {/* Dark gradient overlay at bottom of avatar */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                  </div>
                </div>

                {/* STATUS 24H BADGE */}
                {isStatusActive && (
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 bg-emerald-400 text-black text-[9px] font-black px-1.5 py-0.2 rounded-full border border-black shadow-lg uppercase tracking-tight flex items-center gap-0.5 z-10">
                    <Play className="w-2.5 h-2.5 fill-black" /> STATUS
                  </div>
                )}

                {/* Status Count Badge Pill (Bottom Right) - Only shown if statusCount > 0 */}
                {isStatusActive && (
                  <div className="absolute -bottom-1 -right-1 bg-[#10b981] text-black text-[11px] font-black px-2 py-0.5 rounded-full border-2 border-[#0a0f16] shadow-md flex items-center justify-center min-w-[24px]">
                    {statusCount}
                  </div>
                )}

                {/* Live Pulse Dot on Avatar if no status active */}
                {!isStatusActive && t.isLive && (
                  <div className="absolute top-1 right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-[#0a0f16] shadow-sm animate-ping" />
                )}
              </div>

              {/* Translator Name */}
              <span
                className={`text-xs sm:text-sm font-black uppercase text-center tracking-tight max-w-[90px] truncate transition-colors ${
                  isStatusActive ? 'text-emerald-300 font-extrabold' : isSelected ? 'text-emerald-400' : 'text-gray-200 group-hover:text-emerald-300'
                }`}
              >
                {t.name}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
};
