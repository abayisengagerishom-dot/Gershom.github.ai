import React, { useState } from 'react';
import { X, Smartphone, Download, ShieldCheck, Zap, Tv, CheckCircle2 } from 'lucide-react';

interface GetAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GetAppModal: React.FC<GetAppModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [downloading, setDownloading] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);

  const handleStartDownload = () => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      setDownloadComplete(true);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-[#0c121a] border border-emerald-900/60 rounded-3xl p-6 shadow-2xl shadow-emerald-950/90 text-center">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-800 hover:bg-emerald-500 hover:text-black text-gray-300 flex items-center justify-center transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-emerald-300 p-0.5 mx-auto mb-4 shadow-lg shadow-emerald-500/30">
          <div className="w-full h-full bg-[#0a0f16] rounded-[14px] flex items-center justify-center">
            <Smartphone className="w-8 h-8 text-emerald-400" />
          </div>
        </div>

        <h3 className="text-xl font-extrabold text-white mb-1">
          CINEVA Android App
        </h3>
        <p className="text-xs text-emerald-400 font-semibold mb-4">
          Manura CINEVA APK ku foni yawe ya Android!
        </p>

        {/* Features List */}
        <div className="text-left bg-[#111823] p-4 rounded-2xl border border-emerald-950/60 space-y-2.5 mb-6 text-xs text-gray-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Kurebera filime n'amaserie k'amashusho ya Full HD 1080p</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Kumanura filime ukaza kuzireba udafite internet (Offline)</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Kubona notification za agasobanuye gashya ka Rocky, Kabosio, etc.</span>
          </div>
        </div>

        {/* Download Action */}
        {!downloadComplete ? (
          <button
            onClick={handleStartDownload}
            disabled={downloading}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-300 hover:to-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/30 transition-all"
          >
            {downloading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                Irakuza CINEVA v2.4.apk...
              </span>
            ) : (
              <>
                <Download className="w-5 h-5 stroke-[2.5]" />
                <span>Manura App (APK 18.4 MB)</span>
              </>
            )}
          </button>
        ) : (
          <div className="p-3 bg-emerald-950/60 border border-emerald-500/50 rounded-2xl text-emerald-300 text-xs font-bold flex items-center justify-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            CINEVA APK Yagukukiye! Fungura file kugira ngo uyishyiremo.
          </div>
        )}

      </div>
    </div>
  );
};
