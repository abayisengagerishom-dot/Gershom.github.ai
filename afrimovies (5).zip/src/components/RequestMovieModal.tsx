import React, { useState } from 'react';
import { X, Send, CheckCircle2, Film, MessageCircle } from 'lucide-react';
import { TRANSLATORS } from '../data/mockData';

interface RequestMovieModalProps {
  isOpen: boolean;
  onClose: () => void;
  requestWhatsappNumber?: string;
}

export const RequestMovieModal: React.FC<RequestMovieModalProps> = ({ 
  isOpen, 
  onClose,
  requestWhatsappNumber = '250780000000'
}) => {
  if (!isOpen) return null;

  const [movieName, setMovieName] = useState('');
  const [preferredTranslator, setPreferredTranslator] = useState(TRANSLATORS[0].name);
  const [submitted, setSubmitted] = useState(false);
  const [whatsappUrl, setWhatsappUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!movieName.trim()) return;

    const cleanPhone = requestWhatsappNumber.replace(/\D/g, '') || '250780000000';
    const messageText = `Muraho AfriMovies! Nduza gusaba Filime/Serie: "${movieName.trim()}" isobanuwe na "${preferredTranslator}". Murakoze!`;
    const targetUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(messageText)}`;

    setWhatsappUrl(targetUrl);
    setSubmitted(true);

    try {
      window.open(targetUrl, '_blank');
    } catch (err) {
      console.error("WhatsApp redirect error", err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-[#0c121a] border border-emerald-900/60 rounded-3xl p-6 shadow-2xl shadow-emerald-950/90">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-800 hover:bg-emerald-500 hover:text-black text-gray-300 flex items-center justify-center transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 p-0.5 mx-auto mb-3 border border-emerald-500/40 flex items-center justify-center">
          <Film className="w-7 h-7" />
        </div>

        <h3 className="text-xl font-extrabold text-white text-center mb-1">
          Saba Filime cg Serie
        </h3>
        <p className="text-xs text-gray-400 text-center mb-6">
          Andika izina ry'filime wifuza ko abasobanuzi b'I Kinyarwanda bakusobanurira! Ubusabe buhita bujya kuri WhatsApp.
        </p>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-300 mb-1.5">
                Izina rya Movie / Series:
              </label>
              <input
                type="text"
                required
                placeholder="E.g. Fast & Furious 11, Wednesday Season 2..."
                value={movieName}
                onChange={(e) => setMovieName(e.target.value)}
                className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-300 mb-1.5">
                Umusobanuzi wifuza:
              </label>
              <select
                value={preferredTranslator}
                onChange={(e) => setPreferredTranslator(e.target.value)}
                className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-4 py-2.5 text-xs text-emerald-400 focus:outline-none focus:border-emerald-400 font-bold"
              >
                {TRANSLATORS.map((t) => (
                  <option key={t.id} value={t.name}>
                    {t.name} ({t.alias})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 to-emerald-500 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.02]"
            >
              <MessageCircle className="w-4 h-4 fill-black text-black" />
              <span>Ohereza Ubusabe kuri WhatsApp</span>
            </button>
          </form>
        ) : (
          <div className="p-5 bg-emerald-950/70 border border-emerald-500/60 rounded-2xl text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <p className="text-sm font-extrabold text-white">Ubusabe bwawe bwoherejwe kuri WhatsApp!</p>
            <p className="text-xs text-emerald-300">
              Murakoze! Filime "{movieName}" yasabwe neza. Niba WhatsApp itafungutse, kanda hano:
            </p>
            
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-400 text-black text-xs font-black rounded-xl hover:bg-emerald-300 shadow-md transition-all"
            >
              <MessageCircle className="w-4 h-4" /> Fungura WhatsApp
            </a>

            <div className="pt-2">
              <button
                onClick={() => {
                  setSubmitted(false);
                  setMovieName('');
                  onClose();
                }}
                className="text-xs text-gray-400 underline hover:text-white"
              >
                Funga
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
