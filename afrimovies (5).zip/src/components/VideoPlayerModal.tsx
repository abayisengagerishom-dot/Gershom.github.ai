import React, { useState, useRef } from 'react';
import { Movie, Episode, Comment } from '../types';
import { 
  X, Play, Pause, RotateCcw, RotateCw, Maximize, Download, 
  Heart, Share2, MessageSquare, Star, Film, CheckCircle2, 
  Sparkles, ListVideo, Send, ShieldCheck, Gauge
} from 'lucide-react';

interface VideoPlayerModalProps {
  movie: Movie | null;
  onClose: () => void;
  onOpenGetApp?: () => void;
  downloadsEnabled?: boolean;
  allMovies?: Movie[];
  onSelectMovie?: (movie: Movie) => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  movie,
  onClose,
  downloadsEnabled = true,
  allMovies = [],
  onSelectMovie
}) => {
  if (!movie) return null;

  const [isPlaying, setIsPlaying] = useState(true);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [selectedAudioTrack, setSelectedAudioTrack] = useState<'dub' | 'original'>('dub');
  const [selectedQuality, setSelectedQuality] = useState<string>('1080p');
  const [currentEpisode, setCurrentEpisode] = useState<Episode | null>(
    movie.episodes && movie.episodes.length > 0 ? movie.episodes[0] : null
  );
  const [comments, setComments] = useState<Comment[]>(movie.comments || []);
  const [newCommentText, setNewCommentText] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Sync episode state when movie changes
  React.useEffect(() => {
    if (movie) {
      if (movie.episodes && movie.episodes.length > 0) {
        setCurrentEpisode(movie.episodes[0]);
      } else {
        setCurrentEpisode(null);
      }
    }
  }, [movie]);

  // Derived related & new movies list (matching category or translator, excluding current)
  const relatedMovies = React.useMemo(() => {
    if (!allMovies || allMovies.length === 0) return [];
    const filtered = allMovies.filter(m => m.id !== movie.id);
    filtered.sort((a, b) => {
      const aScore = (a.category === movie.category ? 2 : 0) + (a.translatorName === movie.translatorName ? 1 : 0);
      const bScore = (b.category === movie.category ? 2 : 0) + (b.translatorName === movie.translatorName ? 1 : 0);
      return bScore - aScore;
    });
    return filtered.slice(0, 8);
  }, [allMovies, movie]);

  // Handle Video Ended (Auto-play Next Episode or Next Related Movie)
  const handleVideoEnded = () => {
    // 1. Auto-play next episode if series
    if (movie.type === 'Series' && movie.episodes && movie.episodes.length > 0) {
      const currentEpId = currentEpisode ? currentEpisode.id : movie.episodes[0].id;
      const currentIndex = movie.episodes.findIndex(ep => ep.id === currentEpId);
      if (currentIndex >= 0 && currentIndex < movie.episodes.length - 1) {
        const nextEpisode = movie.episodes[currentIndex + 1];
        setCurrentEpisode(nextEpisode);
        return;
      }
    }

    // 2. Auto-play next movie from allMovies
    if (allMovies && allMovies.length > 0 && onSelectMovie) {
      const currentMovieIdx = allMovies.findIndex(m => m.id === movie.id);
      const nextIdx = (currentMovieIdx + 1) % allMovies.length;
      const nextMovie = allMovies[nextIdx];
      if (nextMovie) {
        onSelectMovie(nextMovie);
      }
    }
  };

  // Ensure playable video URL fallback
  const rawVideoUrl = currentEpisode ? currentEpisode.videoUrl : movie.videoUrl;
  const activeVideoUrl = rawVideoUrl || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

  // Reactively trigger video loading and playback when currentEpisode or activeVideoUrl changes
  React.useEffect(() => {
    if (videoRef.current) {
      videoRef.current.load();
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsPlaying(true))
          .catch((e) => {
            console.log("Auto-play blocked, waiting for user click:", e);
            setIsPlaying(false);
          });
      }
    }
  }, [currentEpisode?.id, activeVideoUrl]);

  const handleRewind = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 10);
    }
  };

  const handleFastForward = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.min(
        videoRef.current.duration || 9999,
        videoRef.current.currentTime + 10
      );
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  };

  const handleSpeedChange = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
  };

  const handleFullscreen = () => {
    if (videoRef.current) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen();
      }
    }
  };

  const handleDownloadMovie = () => {
    setIsDownloading(true);
    try {
      const link = document.createElement('a');
      link.href = activeVideoUrl;
      const fileName = currentEpisode 
        ? `${movie.title}_Ep_${currentEpisode.number}.mp4`
        : `${movie.title}.mp4`;
      link.download = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Direct download failed", err);
    }
    setTimeout(() => setIsDownloading(false), 2500);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      user: 'Umusomyi_AfriMovies',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
      text: newCommentText.trim(),
      time: 'Icyino aha',
      likes: 1
    };

    setComments([newComment, ...comments]);
    setNewCommentText('');
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fade-in">
      
      {/* Modal Card */}
      <div className="relative w-full max-w-4xl bg-[#0c121a] border border-cyan-900/60 rounded-3xl overflow-hidden shadow-2xl shadow-cyan-950/80 my-auto max-h-[92vh] flex flex-col">
        
        {/* Header bar inside modal */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#111823] border-b border-cyan-950/60">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 uppercase">
              {movie.type}
            </span>
            <span className="text-sm font-extrabold text-white truncate max-w-[200px] sm:max-w-xs font-sans">
              {movie.title}
            </span>
            {currentEpisode && (
              <span className="text-xs text-cyan-400 font-medium">
                — Ep {currentEpisode.number}
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-800/80 hover:bg-cyan-500 text-gray-300 hover:text-black flex items-center justify-center transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Container */}
        <div className="relative aspect-video w-full bg-black group overflow-hidden">
          <video
            ref={videoRef}
            src={activeVideoUrl}
            controls
            autoPlay
            playsInline
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={handleVideoEnded}
            className="w-full h-full object-contain"
          />

          {/* PERMANENT WATERMARK OVERLAY - Bottom-Left Corner of Video */}
          <div className="absolute bottom-12 left-3 sm:bottom-14 sm:left-4 z-30 pointer-events-none flex items-center gap-1.5 bg-black/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-amber-500/60 text-white shadow-2xl shadow-black/90">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="font-mono text-xs sm:text-sm font-black tracking-wider text-white uppercase">
              <span className="text-amber-400">AFRI</span>MOVIES
            </span>
            <span className="text-[10px] sm:text-xs text-gray-300 font-extrabold hidden sm:inline">
              • www.afrimovies.com
            </span>
          </div>

          {/* Audio Dubbing watermark indicator (Top-Left) */}
          <div className="absolute top-3 left-3 z-30 bg-black/75 backdrop-blur-md border border-cyan-500/40 px-3 py-1 rounded-full text-[11px] font-extrabold text-cyan-400 flex items-center gap-1.5 pointer-events-none">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            {selectedAudioTrack === 'dub' 
              ? `Agasobanuye by ${movie.translatorName}`
              : 'Original Audio'
            }
          </div>

          {/* Top Right Quick Controls overlay */}
          <div className="absolute top-3 right-3 z-30 flex items-center gap-1.5 bg-black/70 backdrop-blur-md p-1 rounded-xl border border-white/10">
            <button
              onClick={handleRewind}
              className="p-1.5 rounded-lg text-gray-200 hover:text-cyan-400 hover:bg-white/10 transition-colors"
              title="Rewind 10 Seconds"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={togglePlay}
              className="p-1.5 rounded-lg text-gray-200 hover:text-cyan-400 hover:bg-white/10 transition-colors"
              title={isPlaying ? "Pause Video" : "Play Video"}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <button
              onClick={handleFastForward}
              className="p-1.5 rounded-lg text-gray-200 hover:text-cyan-400 hover:bg-white/10 transition-colors"
              title="Fast Forward 10 Seconds"
            >
              <RotateCw className="w-4 h-4" />
            </button>
            <button
              onClick={handleFullscreen}
              className="p-1.5 rounded-lg text-gray-200 hover:text-cyan-400 hover:bg-white/10 transition-colors"
              title="Full Screen"
            >
              <Maximize className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 text-gray-200">
          
          {/* Action & Speed Control Panel */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111823] p-3.5 rounded-2xl border border-cyan-950/60">
            
            {/* Playback Controls (Rewind, Fast Forward, Speed) */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-semibold text-gray-400 flex items-center gap-1">
                <Gauge className="w-3.5 h-3.5 text-cyan-400" /> Controls:
              </span>
              
              <button
                onClick={handleRewind}
                className="px-2.5 py-1 rounded-lg bg-gray-800 text-gray-300 hover:text-white hover:bg-gray-700 text-xs font-bold flex items-center gap-1 transition-colors"
                title="Gusubiza inyuma isegonda 10"
              >
                <RotateCcw className="w-3.5 h-3.5 text-cyan-400" /> -10s
              </button>

              <button
                onClick={handleFastForward}
                className="px-2.5 py-1 rounded-lg bg-gray-800 text-gray-300 hover:text-white hover:bg-gray-700 text-xs font-bold flex items-center gap-1 transition-colors"
                title="Kwihutisha imbere isegonda 10"
              >
                <RotateCw className="w-3.5 h-3.5 text-cyan-400" /> +10s
              </button>

              {/* Speed rate buttons */}
              <div className="flex items-center bg-gray-900 p-0.5 rounded-lg border border-gray-800 text-[11px] font-bold">
                {[1, 1.25, 1.5, 2].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => handleSpeedChange(rate)}
                    className={`px-2 py-0.5 rounded transition-all ${
                      playbackRate === rate
                        ? 'bg-cyan-400 text-black font-extrabold'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    {rate}x
                  </button>
                ))}
              </div>
            </div>

            {/* Audio Track & Downloads */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1 bg-gray-900 p-0.5 rounded-lg border border-gray-800 text-xs">
                <button
                  onClick={() => setSelectedAudioTrack('dub')}
                  className={`px-2.5 py-0.5 rounded text-xs font-bold transition-all ${
                    selectedAudioTrack === 'dub'
                      ? 'bg-cyan-400 text-black'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  Kinyarwanda
                </button>
                <button
                  onClick={() => setSelectedAudioTrack('original')}
                  className={`px-2.5 py-0.5 rounded text-xs font-bold transition-all ${
                    selectedAudioTrack === 'original'
                      ? 'bg-cyan-400 text-black'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  Original
                </button>
              </div>

              <select
                value={selectedQuality}
                onChange={(e) => setSelectedQuality(e.target.value)}
                className="bg-gray-900 text-cyan-400 border border-cyan-900/60 rounded-lg px-2 py-1 text-xs font-bold focus:outline-none"
              >
                <option value="1080p">1080p HD</option>
                <option value="720p">720p HD</option>
                <option value="480p">480p SD</option>
              </select>

              <button
                onClick={handleShare}
                className="p-1.5 rounded-xl bg-gray-800 border border-gray-700 text-gray-300 hover:text-cyan-400 transition-all relative"
                title="Share link"
              >
                <Share2 className="w-4 h-4" />
                {copiedLink && (
                  <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-cyan-500 text-black text-[10px] font-bold px-2 py-0.5 rounded shadow">
                    Copied!
                  </span>
                )}
              </button>

              {downloadsEnabled && (
                <button
                  onClick={handleDownloadMovie}
                  className={`px-3 py-1.5 rounded-xl text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md transition-all ${
                    isDownloading 
                      ? 'bg-cyan-300 animate-pulse'
                      : 'bg-gradient-to-r from-cyan-400 to-sky-400 hover:brightness-110 shadow-cyan-500/30'
                  }`}
                  title="Save video to device storage"
                >
                  {isDownloading ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-black" /> Downloading...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4 stroke-[2.5]" /> Download Video
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Series Episodes List (If movie is a Series) */}
          {movie.type === 'Series' && movie.episodes && movie.episodes.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <ListVideo className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-extrabold text-white">
                  Episodes ({movie.episodes.length})
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {movie.episodes.map((ep) => {
                  const isSelected = currentEpisode?.id === ep.id;
                  return (
                    <button
                      key={ep.id}
                      onClick={() => {
                        setCurrentEpisode(ep);
                      }}
                      className={`flex items-center gap-3 p-2.5 rounded-xl text-left border transition-all ${
                        isSelected
                          ? 'bg-cyan-950/80 border-cyan-400 text-white shadow-md shadow-cyan-500/20'
                          : 'bg-[#111823] border-gray-800 text-gray-300 hover:border-cyan-500/40'
                      }`}
                    >
                      <div className="relative w-14 h-10 rounded-lg overflow-hidden bg-black flex-shrink-0">
                        <img src={ep.thumbnail} alt={ep.title} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                          <Play className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-400 fill-cyan-400' : 'text-white'}`} />
                        </div>
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate">{ep.title}</p>
                        <p className="text-[10px] text-cyan-400/80">{ep.duration}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Details & Synopsis */}
          <div className="space-y-3">
            <div className="flex items-center gap-3 flex-wrap text-xs text-gray-400 font-medium">
              <span className="text-white font-black text-lg">{movie.title}</span>
              <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-bold border border-cyan-500/30">
                {movie.year}
              </span>
              <span className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400" /> {movie.rating}
              </span>
              <span>•</span>
              <span className="text-cyan-300 font-semibold">Agasobanuye: {movie.translatorName}</span>
              <span>•</span>
              <span>{movie.views} views</span>
            </div>

            <p className="text-xs sm:text-sm text-gray-300 leading-relaxed bg-[#111823] p-4 rounded-2xl border border-cyan-950/40">
              {movie.description}
            </p>
          </div>

          {/* Related & New Movies Grid (Auto-play Next) */}
          {relatedMovies.length > 0 && (
            <div className="space-y-3 pt-4 border-t border-cyan-950/60">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Film className="w-4 h-4 text-amber-400" />
                  <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider">
                    FILIME ZIFITANYE ISANO N'IZINDI NSHYA (RELATED & NEW)
                  </h3>
                </div>
                <span className="text-[10px] text-amber-400 font-extrabold uppercase bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" /> Auto-Play Next
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                {relatedMovies.map((relMovie) => (
                  <button
                    key={relMovie.id}
                    type="button"
                    onClick={() => {
                      if (onSelectMovie) onSelectMovie(relMovie);
                    }}
                    className="group relative bg-[#111823] hover:bg-cyan-950/80 border border-gray-800 hover:border-amber-500/60 rounded-2xl overflow-hidden text-left transition-all hover:scale-[1.02] flex flex-col shadow-md"
                  >
                    <div className="relative aspect-[16/10] w-full bg-black overflow-hidden">
                      <img
                        src={relMovie.poster || relMovie.banner}
                        alt={relMovie.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 flex items-center justify-center opacity-80 group-hover:opacity-100 transition-opacity">
                        <div className="w-8 h-8 rounded-full bg-amber-500 text-black flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                          <Play className="w-4 h-4 fill-black ml-0.5" />
                        </div>
                      </div>
                      <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded text-[9px] font-black bg-cyan-500 text-black uppercase">
                        {relMovie.category}
                      </span>
                    </div>

                    <div className="p-2 flex-1 flex flex-col justify-between">
                      <p className="text-xs font-bold text-white truncate group-hover:text-amber-400 transition-colors">
                        {relMovie.title}
                      </p>
                      <p className="text-[10px] text-gray-400 truncate mt-0.5">
                        Isobanuwe na <span className="text-cyan-300 font-semibold">{relMovie.translatorName}</span>
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Comments Section */}
          <div className="space-y-4 pt-4 border-t border-cyan-950/60">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Ibibazo n'Ibibitekerezo ({comments.length})
              </h3>
            </div>

            {/* Comment Form */}
            <form onSubmit={handleAddComment} className="flex gap-2">
              <input
                type="text"
                placeholder="Andika igitekerezo cyawe aha..."
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="flex-1 bg-[#111823] border border-cyan-900/60 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-gradient-to-r from-cyan-400 to-sky-400 text-black font-extrabold text-xs rounded-xl flex items-center gap-1 transition-colors"
              >
                <Send className="w-3.5 h-3.5" /> Ohereza
              </button>
            </form>

            {/* Comments List */}
            <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
              {comments.map((c) => (
                <div key={c.id} className="bg-[#111823] p-3 rounded-xl border border-cyan-950/40 flex items-start gap-3">
                  <img src={c.avatar} alt={c.user} className="w-7 h-7 rounded-full object-cover flex-shrink-0" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-400">{c.user}</span>
                      <span className="text-[10px] text-gray-500">{c.time}</span>
                    </div>
                    <p className="text-xs text-gray-300 mt-0.5">{c.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
