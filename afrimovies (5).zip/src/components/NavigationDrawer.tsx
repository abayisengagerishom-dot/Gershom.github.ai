import React from 'react';
import { X, Film, Tv, Languages, Users, MessageSquarePlus, Folder, Sparkles } from 'lucide-react';
import { NavTab } from '../types';
import { VLCLogo } from './VLCLogo';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTab: (tab: NavTab) => void;
  onOpenJoinCommunity: () => void;
  onRequestMovie: () => void;
  onOpenAiScan?: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  onSelectTab,
  onOpenJoinCommunity,
  onRequestMovie,
  onOpenAiScan
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex justify-end animate-fade-in">
      <div className="w-full max-w-xs bg-[#0a0f16] border-l border-cyan-900/60 h-full p-6 flex flex-col justify-between overflow-y-auto">
        
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-6 border-b border-cyan-950/80">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#0d131d] border border-amber-500/50 flex items-center justify-center p-0.5">
                <VLCLogo className="w-6 h-6" />
              </div>
              <span className="font-extrabold text-white text-base tracking-wider font-mono">
                <span className="text-amber-400">Afri</span>Movies
              </span>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-gray-800 hover:bg-cyan-400 hover:text-black text-gray-300 flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <div className="mt-6 space-y-2">
            {/* AI Video Scan Special Button */}
            {onOpenAiScan && (
              <button
                onClick={() => { onOpenAiScan(); onClose(); }}
                className="w-full flex items-center gap-3 p-3.5 rounded-2xl text-sm font-extrabold text-black bg-gradient-to-r from-cyan-400 to-sky-400 hover:brightness-110 transition-all text-left shadow-lg shadow-cyan-500/20"
              >
                <Sparkles className="w-5 h-5 fill-black" />
                <span>AI Video Scan (Shaka Movie)</span>
              </button>
            )}

            <button
              onClick={() => { onSelectTab('home'); onClose(); }}
              className="w-full flex items-center gap-3 p-3 rounded-2xl text-sm font-bold text-gray-200 hover:text-cyan-400 hover:bg-[#121a24] transition-all text-left"
            >
              <Film className="w-5 h-5 text-cyan-400" /> Ahaguruka (Home)
            </button>

            {/* Prominent All Series Folders Button */}
            <button
              onClick={() => { onSelectTab('all_series'); onClose(); }}
              className="w-full flex items-center gap-3 p-3 rounded-2xl text-sm font-extrabold text-cyan-300 bg-cyan-950/60 border border-cyan-500/40 hover:bg-cyan-900/60 transition-all text-left shadow-lg shadow-cyan-950/80"
            >
              <Folder className="w-5 h-5 text-cyan-400" /> All Series (Folders)
            </button>

            <button
              onClick={() => { onSelectTab('series'); onClose(); }}
              className="w-full flex items-center gap-3 p-3 rounded-2xl text-sm font-bold text-gray-200 hover:text-cyan-400 hover:bg-[#121a24] transition-all text-left"
            >
              <Tv className="w-5 h-5 text-cyan-400" /> Amaserie (Series)
            </button>

            <button
              onClick={() => { onSelectTab('dub'); onClose(); }}
              className="w-full flex items-center gap-3 p-3 rounded-2xl text-sm font-bold text-gray-200 hover:text-cyan-400 hover:bg-[#121a24] transition-all text-left"
            >
              <Languages className="w-5 h-5 text-cyan-400" /> Agasobanuye (Dubbed)
            </button>

            <button
              onClick={() => { onRequestMovie(); onClose(); }}
              className="w-full flex items-center gap-3 p-3 rounded-2xl text-sm font-bold text-gray-200 hover:text-cyan-400 hover:bg-[#121a24] transition-all text-left"
            >
              <MessageSquarePlus className="w-5 h-5 text-cyan-400" /> Saba Filime (Request)
            </button>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-6 border-t border-cyan-950/80 space-y-3">
          <button
            onClick={() => { onOpenJoinCommunity(); onClose(); }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-400 to-sky-400 hover:brightness-110 text-black font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all"
          >
            <Users className="w-4 h-4" /> Join WhatsApp Group
          </button>

          <p className="text-[10px] text-gray-500 text-center pt-2">
            © {new Date().getFullYear()} AfriMovies Streaming. All rights reserved.
          </p>
        </div>

      </div>
    </div>
  );
};
