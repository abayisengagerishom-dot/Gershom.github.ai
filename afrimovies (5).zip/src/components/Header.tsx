import React from 'react';
import { Search, Menu, Film, Radio, ShieldCheck, Sparkles } from 'lucide-react';
import { VLCLogo } from './VLCLogo';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenMenu: () => void;
  onOpenAdmin: () => void;
  onOpenAiScan: () => void;
  activeTranslatorName?: string | null;
  onClearTranslatorFilter?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenMenu,
  onOpenAdmin,
  onOpenAiScan,
  activeTranslatorName,
  onClearTranslatorFilter
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0a0f16]/95 backdrop-blur-md border-b border-cyan-950/60 px-4 py-3 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Brand Logo & Title with VLC Media Player Logo */}
        <div className="flex items-center gap-3 cursor-pointer group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-amber-600 p-[1.5px] shadow-lg shadow-orange-500/30 group-hover:shadow-orange-500/50 transition-all">
            <div className="w-full h-full bg-[#0d131d] rounded-[10px] flex items-center justify-center p-1">
              <VLCLogo className="w-7 h-7 drop-shadow-md" />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold tracking-wider text-white font-mono uppercase flex items-center gap-1.5">
                <span className="text-amber-400">Afri</span>Movies
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/40 shadow-sm">
                <Radio className="w-2.5 h-2.5 animate-pulse text-amber-400" /> HD STREAM
              </span>
            </div>
            <p className="text-[10px] text-amber-400 font-bold tracking-widest uppercase">
              PREMIUM STREAMING
            </p>
          </div>
        </div>

        {/* Translator Filter active pill if selected */}
        {activeTranslatorName && (
          <div className="hidden md:flex items-center gap-2 bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 px-3 py-1 rounded-full text-xs animate-fade-in">
            <span>Filter by: <strong className="text-white">{activeTranslatorName}</strong></span>
            <button 
              onClick={onClearTranslatorFilter}
              className="text-cyan-400 hover:text-white font-bold ml-1 bg-cyan-900/60 w-4 h-4 rounded-full flex items-center justify-center text-[10px]"
              title="Clear Filter"
            >
              ✕
            </button>
          </div>
        )}

        {/* Quick Actions Header */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* AI Video Scan Prominent Button */}
          <button
            onClick={onOpenAiScan}
            className="px-2 sm:px-3 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-400 hover:brightness-110 text-black font-extrabold text-xs flex items-center gap-1 transition-all shadow-md shadow-cyan-500/20"
            title="AI Video Scan - Find film name from clip frame"
          >
            <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-black" />
            <span className="hidden xs:inline sm:inline font-mono text-[11px] sm:text-xs">AI Scan</span>
          </button>

          {/* Admin Panel Button */}
          <button
            onClick={onOpenAdmin}
            className="px-2 sm:px-3 py-2 rounded-xl bg-cyan-950/80 hover:bg-cyan-400 border border-cyan-500/40 text-cyan-300 hover:text-black font-extrabold text-xs flex items-center gap-1 transition-all shadow-md shadow-cyan-950/50"
            title="Open Admin Login / Video Upload"
          >
            <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Admin</span>
          </button>

          {/* Search Button */}
          <button
            onClick={onOpenSearch}
            className="w-8 sm:w-10 h-8 sm:h-10 rounded-xl bg-[#131b26] border border-cyan-900/50 hover:border-cyan-500/50 text-gray-300 hover:text-cyan-400 flex items-center justify-center transition-all hover:scale-105 active:scale-95"
            aria-label="Search Movies"
          >
            <Search className="w-4 sm:w-5 h-4 sm:h-5" />
          </button>

          {/* Menu Drawer Toggle - 3 Lines Icon (Highly visible in top right corner on phone form & desktop) */}
          <button
            onClick={onOpenMenu}
            className="w-9 sm:w-10 h-9 sm:h-10 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black border-2 border-emerald-300 flex items-center justify-center transition-all hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/40 cursor-pointer flex-shrink-0"
            aria-label="Open Navigation Menu (3 Lines)"
            title="Menu (3 Lines)"
          >
            <Menu className="w-5 sm:w-6 h-5 sm:h-6 stroke-[3] text-black" />
          </button>
        </div>

      </div>
    </header>
  );
};
