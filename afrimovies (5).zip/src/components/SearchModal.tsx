import React, { useState } from 'react';
import { Movie, Translator } from '../types';
import { Search, X, Film, Sparkles } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  movies: Movie[];
  translators: Translator[];
  onSelectMovie: (movie: Movie) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  movies,
  translators,
  onSelectMovie
}) => {
  if (!isOpen) return null;

  const [query, setQuery] = useState('');
  const [selectedTranslatorFilter, setSelectedTranslatorFilter] = useState<string | null>(null);

  const results = movies.filter((m) => {
    const matchesQuery = 
      m.title.toLowerCase().includes(query.toLowerCase()) ||
      m.translatorName.toLowerCase().includes(query.toLowerCase()) ||
      m.category.toLowerCase().includes(query.toLowerCase());

    const matchesTranslator = selectedTranslatorFilter
      ? m.translatorId === selectedTranslatorFilter
      : true;

    return matchesQuery && matchesTranslator;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-start justify-center p-4 pt-16 sm:pt-20 animate-fade-in">
      <div className="relative w-full max-w-2xl bg-[#0c121a] border border-emerald-900/60 rounded-3xl overflow-hidden shadow-2xl shadow-emerald-950/80">
        
        {/* Search Header */}
        <div className="p-4 bg-[#111823] border-b border-emerald-950/60 flex items-center gap-3">
          <Search className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Shaka filime, serie, cyangwa umusobanuzi (Rocky, Kabosio, Sankara)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-white placeholder-gray-500 font-medium text-sm focus:outline-none"
          />
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-800 hover:bg-emerald-500 hover:text-black text-gray-300 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Translator Filter Quick Chips */}
        <div className="p-3 bg-[#0d141e] border-b border-emerald-950/40 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-xs font-bold text-gray-400 flex-shrink-0">Translators:</span>
          <button
            onClick={() => setSelectedTranslatorFilter(null)}
            className={`px-3 py-1 rounded-full text-xs font-extrabold flex-shrink-0 ${
              selectedTranslatorFilter === null
                ? 'bg-emerald-400 text-black'
                : 'bg-gray-800 text-gray-300 hover:text-white'
            }`}
          >
            All
          </button>
          {translators.map((t) => (
            <button
              key={t.id}
              onClick={() =>
                setSelectedTranslatorFilter(
                  selectedTranslatorFilter === t.id ? null : t.id
                )
              }
              className={`px-3 py-1 rounded-full text-xs font-extrabold flex-shrink-0 transition-all ${
                selectedTranslatorFilter === t.id
                  ? 'bg-emerald-400 text-black shadow-md shadow-emerald-500/30'
                  : 'bg-gray-800 text-gray-300 hover:text-emerald-300'
              }`}
            >
              {t.name}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="p-4 max-h-[60vh] overflow-y-auto space-y-3">
          {results.length > 0 ? (
            results.map((movie) => (
              <div
                key={movie.id}
                onClick={() => {
                  onSelectMovie(movie);
                  onClose();
                }}
                className="flex items-center gap-3 p-2.5 rounded-2xl bg-[#111823] hover:bg-[#182333] border border-emerald-950/40 hover:border-emerald-500/50 cursor-pointer transition-all group"
              >
                <img
                  src={movie.poster}
                  alt={movie.title}
                  className="w-14 h-18 object-cover rounded-xl flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {movie.year}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-400 text-black">
                      {movie.translatorName}
                    </span>
                  </div>
                  <h4 className="text-sm font-extrabold text-white group-hover:text-emerald-300 truncate">
                    {movie.title}
                  </h4>
                  <p className="text-xs text-gray-400 truncate mt-0.5">
                    {movie.category} • {movie.type} • {movie.rating} ★
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-10 text-gray-400">
              <Film className="w-10 h-10 text-emerald-500/40 mx-auto mb-2" />
              <p className="text-sm font-bold">Nta filime ibonetse ihuye n'ibyo ushakashatse.</p>
              <p className="text-xs text-gray-500 mt-1">Gerageza gushakisha izina rya movie cyangwa umusobanuzi.</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
