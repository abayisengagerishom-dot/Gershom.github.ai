import React, { useState } from 'react';
import { Play, Film, Star, Download, CheckCircle2 } from 'lucide-react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
  onSelect: (movie: Movie) => void;
  downloadsEnabled?: boolean;
}

export const MovieCard: React.FC<MovieCardProps> = ({ movie, onSelect, downloadsEnabled = true }) => {
  const [imgError, setImgError] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDownloading(true);

    try {
      const link = document.createElement('a');
      link.href = movie.videoUrl || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
      link.download = `${movie.title.replace(/[^a-zA-Z0-9 ]/g, '')}.mp4`;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Download trigger", err);
    }

    setTimeout(() => {
      setDownloading(false);
    }, 2500);
  };

  return (
    <div
      onClick={() => onSelect(movie)}
      className="group relative flex flex-col bg-[#111721] rounded-2xl overflow-hidden border border-emerald-950/50 hover:border-emerald-500/60 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-950/40 cursor-pointer hover:-translate-y-1"
    >
      {/* Poster Container - Reduced height (aspect-[16/10]) by ~1.5x */}
      <div className="relative aspect-[16/10] w-full bg-[#182230] overflow-hidden">
        {!imgError ? (
          <img
            src={movie.poster}
            alt={movie.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-[#141c27] text-gray-400 text-center">
            <Film className="w-10 h-10 mb-2 text-emerald-500/50" />
            <span className="text-xs font-semibold">No Image</span>
          </div>
        )}

        {/* Top Badges matching exact CINEVA screenshot */}
        <div className="absolute top-2 left-2 right-2 flex items-center justify-between gap-1 z-10">
          <div className="flex items-center gap-1">
            {/* Year Pill Badge */}
            <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-black/70 text-gray-200 border border-white/10 backdrop-blur-md">
              {movie.year}
            </span>

            {/* Status Tag Badge */}
            {movie.status && (
              <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-black tracking-wider uppercase border ${
                movie.status === 'LIVE' ? 'bg-red-500 text-white border-red-400 animate-pulse' :
                movie.status === 'NEW' ? 'bg-emerald-400 text-black border-emerald-300' :
                movie.status === 'TRENDING' ? 'bg-amber-400 text-black border-amber-300' :
                movie.status === 'EXCLUSIVE' ? 'bg-purple-500 text-white border-purple-400' :
                'bg-blue-500 text-white border-blue-400'
              }`}>
                {movie.status}
              </span>
            )}
          </div>

          {/* Translator Green Badge Pill */}
          <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-[#10b981] text-black tracking-tight shadow-md flex items-center gap-1 uppercase">
            {movie.translatorName}
          </span>
        </div>

        {/* Play Icon Hover Overlay */}
        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-[2px]">
          <div className="w-12 h-12 rounded-full bg-emerald-400 text-black flex items-center justify-center shadow-lg shadow-emerald-500/50 transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play className="w-6 h-6 fill-black translate-x-[1px]" />
          </div>
        </div>

        {/* Gradient Bottom Fade */}
        <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#111721] to-transparent pointer-events-none" />
      </div>

      {/* Card Information */}
      <div className="p-3.5 flex flex-col flex-1 justify-between">
        <div>
          <h3 className="text-sm font-extrabold text-white group-hover:text-emerald-400 transition-colors line-clamp-1 tracking-wide font-sans">
            {movie.title}
          </h3>
        </div>

        {/* Download Button Action Row */}
        <div className="mt-2 pt-2 border-t border-emerald-950/40 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 text-[11px] text-gray-400 font-medium">
            <span>{movie.year}</span>
            <span>•</span>
            <span className="text-emerald-400 font-bold">{movie.type}</span>
          </div>

          {/* Direct Download Button (Controlled by Admin Download Controller) */}
          {downloadsEnabled && (
            <button
              onClick={handleDownload}
              className={`px-2.5 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1 transition-all shadow-md ${
                downloading
                  ? 'bg-emerald-400 text-black animate-pulse'
                  : 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-black border border-emerald-500/40'
              }`}
              title="Download Movie to Device Storage"
            >
              {downloading ? (
                <>
                  <CheckCircle2 className="w-3 h-3 text-black" />
                  <span>Downloading...</span>
                </>
              ) : (
                <>
                  <Download className="w-3 h-3 stroke-[2.5]" />
                  <span>Download</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
