import React from 'react';
import { X, MessageCircle, Send, Users } from 'lucide-react';

interface JoinCommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
  whatsappLink?: string;
}

export const JoinCommunityModal: React.FC<JoinCommunityModalProps> = ({
  isOpen,
  onClose,
  whatsappLink = 'https://chat.whatsapp.com/afrimovies-official-community'
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-[#0c121a] border border-emerald-900/60 rounded-3xl p-6 shadow-2xl shadow-emerald-950/90 text-center">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-800 hover:bg-emerald-500 hover:text-black text-gray-300 flex items-center justify-center transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-16 h-16 rounded-2xl bg-[#00E676] text-black p-0.5 mx-auto mb-4 shadow-lg shadow-emerald-500/30 flex items-center justify-center">
          <Users className="w-8 h-8" />
        </div>

        <h3 className="text-xl font-extrabold text-white mb-1">
          Injira mu Muryango wa AfriMovies
        </h3>
        <p className="text-xs text-emerald-400 font-semibold mb-6">
          Sanga abandi bakunzi b'agasobanuye kuri WhatsApp Group n'amatsinda yacu!
        </p>

        <div className="space-y-3">
          {/* WhatsApp Group Link */}
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-black font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all"
          >
            <MessageCircle className="w-5 h-5 stroke-[2.5]" />
            <span>Injira mu Itsinda rya WhatsApp</span>
          </a>

          {/* Telegram Channel Link */}
          <a
            href="https://t.me/afrimovies_official"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-4 rounded-2xl bg-[#229ED9] hover:bg-[#1f8ec3] text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition-all"
          >
            <Send className="w-5 h-5" />
            <span>Sanga AfriMovies kuri Telegram</span>
          </a>
        </div>

        <p className="text-[11px] text-gray-400 mt-5">
          Uzafumukamo amakuru y'agasobanuye gashya, filime zizasohoka, n'amaserie agezweho.
        </p>

      </div>
    </div>
  );
};
