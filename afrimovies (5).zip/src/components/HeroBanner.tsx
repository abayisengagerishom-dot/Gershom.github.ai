import React, { useState, useEffect } from 'react';
import { Play, Info, Sparkles, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { Movie, HeroSlide } from '../types';

interface HeroBannerProps {
  featuredMovies: Movie[];
  heroSlides?: HeroSlide[];
  onSelectMovie: (movie: Movie) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ featuredMovies, heroSlides, onSelectMovie }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Normalize slide items list
  const slidesList: Array<{
    id: string;
    title: string;
    translatorName: string;
    description: string;
    image: string;
    videoUrl?: string;
    rating?: number;
    year?: number;
    type?: 'Movie' | 'Series';
    category?: string;
    originalMovie?: Movie;
  }> = (heroSlides && heroSlides.length > 0)
    ? heroSlides.map(s => ({
        id: s.id,
        title: s.title,
        translatorName: s.translatorName,
        description: s.description,
        image: s.image,
        videoUrl: s.videoUrl,
        rating: s.rating,
        year: s.year,
        type: s.type,
        category: s.category,
        originalMovie: featuredMovies.find(m => m.id === s.id || m.title.toLowerCase() === s.title.toLowerCase())
      }))
    : featuredMovies.map(m => ({
        id: m.id,
        title: m.title,
        translatorName: m.translatorName,
        description: m.description,
        image: m.banner || m.poster,
        videoUrl: m.videoUrl,
        rating: m.rating,
        year: m.year,
        type: m.type,
        category: m.category,
        originalMovie: m
      }));

  useEffect(() => {
    if (slidesList.length === 0) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slidesList.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slidesList.length]);

  if (!slidesList.length) return null;

  const current = slidesList[currentIndex];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % slidesList.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + slidesList.length) % slidesList.length);
  };

  const handleSlideClick = () => {
    if (current.originalMovie) {
      onSelectMovie(current.originalMovie);
    } else {
      // Build dummy movie for custom slide
      const customMovie: Movie = {
        id: current.id,
        title: current.title,
        translatorId: 'rocky',
        translatorName: current.translatorName || 'ROCKY KIMO',
        category: (current.category as any) || 'Agasobanuye',
        type: current.type || 'Movie',
        poster: current.image,
        banner: current.image,
        rating: current.rating || 4.9,
        views: '120K',
        description: current.description,
        year: current.year || 2024,
        videoUrl: current.videoUrl || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        comments: [],
        quality: 'HD 1080p'
      };
      onSelectMovie(customMovie);
    }
  };

  return (
    <div className="relative w-full h-[360px] sm:h-[440px] md:h-[500px] overflow-hidden bg-[#070b12] border-b border-slate-800/60">
      {/* Background Banner Image with Smooth Gradient Vignette */}
      <div className="absolute inset-0 transition-all duration-1000 ease-in-out">
        <img
          src={current.image}
          alt={current.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-100 filter brightness-105 contrast-[1.05] saturate-[1.05] transition-all duration-1000"
        />
        {/* Subtle Clean Gradient Overlay for HD Picture Quality */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#070b12] via-[#070b12]/30 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#070b12]/80 via-transparent to-transparent" />
      </div>

      {/* Hero Content Overlay */}
      <div className="relative max-w-7xl mx-auto h-full px-4 sm:px-6 flex flex-col justify-end pb-8 sm:pb-12 z-10">
        
        {/* Category & Translator Badge */}
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <span className="px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-400/30 flex items-center gap-1.5 backdrop-blur-md shadow-lg shadow-cyan-950/50">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" /> Agasobanuye by {current.translatorName}
          </span>
          {current.year && (
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-900/80 text-slate-300 border border-slate-700/60 backdrop-blur-md">
              {current.year}
            </span>
          )}
          {current.rating && (
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 backdrop-blur-md flex items-center gap-1">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" /> {current.rating}
            </span>
          )}
        </div>

        {/* Title */}
        <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-white tracking-tight drop-shadow-xl mb-2 font-sans max-w-3xl line-clamp-2">
          {current.title}
        </h2>

        {/* Short Description */}
        <p className="text-xs sm:text-sm text-slate-300 max-w-xl line-clamp-2 mb-6 drop-shadow leading-relaxed font-medium">
          {current.description}
        </p>

        {/* Action Buttons with Sleek Cyan/Blue Aesthetic */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleSlideClick}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-sm sm:text-base tracking-wide flex items-center gap-2.5 shadow-xl shadow-cyan-500/25 hover:shadow-cyan-400/40 transition-all hover:scale-105 active:scale-95"
          >
            <Play className="w-5 h-5 fill-black text-black stroke-[1.5]" />
            <span>Reba {current.type === 'Series' ? 'Serie' : 'Filime'}</span>
          </button>

          <button
            onClick={handleSlideClick}
            className="px-5 py-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-slate-200 font-bold text-xs sm:text-sm border border-slate-700/80 backdrop-blur-md flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
          >
            <Info className="w-4.5 h-4.5 text-cyan-400" />
            <span>Zisobanuye</span>
          </button>
        </div>

        {/* Carousel Pagination Indicators */}
        <div className="flex items-center justify-between mt-6 pt-2">
          <div className="flex items-center gap-1.5">
            {slidesList.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`transition-all duration-300 rounded-full ${
                  idx === currentIndex
                    ? 'w-8 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 shadow-md shadow-cyan-500/50'
                    : 'w-2 h-2 bg-white/30 hover:bg-white/60'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Manual prev/next arrows */}
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={handlePrev}
              className="w-8 h-8 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/70 text-slate-200 flex items-center justify-center transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              className="w-8 h-8 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700/70 text-slate-200 flex items-center justify-center transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

