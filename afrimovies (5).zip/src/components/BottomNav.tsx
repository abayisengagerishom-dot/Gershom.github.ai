import React from 'react';
import { NavTab } from '../types';
import { Home, Compass, Tv, Languages, Globe, Search } from 'lucide-react';

interface BottomNavProps {
  activeTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
  onOpenSearch: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  onOpenSearch
}) => {
  const tabs = [
    { id: 'home' as NavTab, label: 'Home', icon: Home },
    { id: 'browse' as NavTab, label: 'Browse', icon: Compass },
    { id: 'series' as NavTab, label: 'Series', icon: Tv },
    { id: 'dub' as NavTab, label: 'Dub', icon: Languages },
    { id: 'nation' as NavTab, label: 'Nation', icon: Globe },
    { id: 'search' as NavTab, label: 'Search', icon: Search, isAction: true },
  ];

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 bg-[#080d14]/95 backdrop-blur-lg border-t border-emerald-950/80 px-2 py-2 sm:hidden">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.isAction) {
                  onOpenSearch();
                } else {
                  onChangeTab(tab.id);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              className={`flex flex-col items-center justify-center flex-1 py-1 px-1 transition-all ${
                isActive
                  ? 'text-[#00E676] scale-105 font-bold'
                  : 'text-gray-400 hover:text-gray-200 font-medium'
              }`}
            >
              <div className={`relative p-1 rounded-full ${isActive ? 'bg-emerald-500/10' : ''}`}>
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                {isActive && (
                  <span className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 bg-[#00E676] rounded-full shadow-sm shadow-[#00E676]" />
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
