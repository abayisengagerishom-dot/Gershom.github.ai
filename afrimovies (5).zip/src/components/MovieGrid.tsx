import React, { useState } from 'react';
import { Movie, MovieCategory } from '../types';
import { MovieCard } from './MovieCard';
import { Sparkles, ChevronRight, Film, Tv, Flame, Radio, Folder, Star, Zap, Layers, BellRing, Filter } from 'lucide-react';

interface MovieGridProps {
  movies: Movie[];
  onSelectMovie: (movie: Movie) => void;
  activeCategory: string;
  onChangeCategory: (category: string) => void;
  activeTranslatorName?: string | null;
  downloadsEnabled?: boolean;
  onSelectSeriesFolderView?: () => void;
}

const CATEGORIES = ['All', 'New Movies', 'Agasobanuye', 'Series', 'Action', 'Drama', 'Sci-Fi', 'Comedy', 'Thriller', 'Romance'];

export const MovieGrid: React.FC<MovieGridProps> = ({
  movies,
  onSelectMovie,
  activeCategory,
  onChangeCategory,
  activeTranslatorName,
  downloadsEnabled = true,
  onSelectSeriesFolderView
}) => {
  const [subFilter, setSubFilter] = useState<string>('all');

  // Reset subfilter when category changes
  React.useEffect(() => {
    setSubFilter('all');
  }, [activeCategory]);

  // Helper to filter movies for specific section
  const getSectionMovies = (sectionName: string) => {
    let base = movies;
    if (sectionName === 'New Movies') {
      base = movies.filter(m => m.isLatest || m.status === 'NEW' || m.category === 'New Movies');
    } else if (sectionName === 'Agasobanuye') {
      base = movies; // All movies are dubbed agasobanuye
    } else if (sectionName === 'Series') {
      base = movies.filter(m => m.type === 'Series' || m.category === 'Series');
    } else {
      base = movies.filter(m => m.category.toLowerCase() === sectionName.toLowerCase());
    }

    if (subFilter === 'all') return base;
    if (subFilter === 'korea') return base.filter(m => m.title.toLowerCase().includes('korea') || m.description.toLowerCase().includes('korea') || m.category.toLowerCase().includes('korea'));
    if (subFilter === 'american') return base.filter(m => m.title.toLowerCase().includes('american') || m.description.toLowerCase().includes('american') || m.category.toLowerCase().includes('american'));
    if (subFilter === 'top_rated') return base.filter(m => (m.rating && m.rating >= 4.8) || m.status === 'EXCLUSIVE' || m.status === 'TRENDING');
    if (subFilter === 'rocky') return base.filter(m => m.translatorName.toLowerCase().includes('rocky'));
    if (subFilter === 'kabosio') return base.filter(m => m.translatorName.toLowerCase().includes('kabosio'));
    if (subFilter === 'sankara') return base.filter(m => m.translatorName.toLowerCase().includes('sankara') || m.translatorName.toLowerCase().includes('hakim'));
    
    return base;
  };

  // If a specific non-'All' category tab is active
  const isFilteredCategory = activeCategory !== 'All';

  const filteredMovies = isFilteredCategory
    ? getSectionMovies(activeCategory)
    : movies;

  // List of sections to display when on 'All' view
  const sectionsToDisplay = [
    { title: 'New Movies', badge: 'LATEST', key: 'New Movies' },
    { title: 'Agasobanuye', badge: 'DUBLD', key: 'Agasobanuye' },
    { title: 'Series', badge: 'SHOWS', key: 'Series' },
    { title: 'Action', badge: 'HOT', key: 'Action' },
    { title: 'Drama', badge: 'POPULAR', key: 'Drama' },
    { title: 'Sci-Fi', badge: 'FUTURE', key: 'Sci-Fi' },
    { title: 'Comedy', badge: 'FUNNY', key: 'Comedy' },
    { title: 'Thriller', badge: 'SCARY', key: 'Thriller' },
    { title: 'Romance', badge: 'LOVE', key: 'Romance' }
  ];

  return (
    <div className="py-6 px-4 max-w-7xl mx-auto space-y-10">
      
      {/* Category Filter Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none sticky top-[61px] z-30 bg-[#0a0f16]/90 backdrop-blur-md py-3 -mx-4 px-4 border-b border-emerald-950/40">
        {CATEGORIES.map((cat) => {
          const isActive = activeCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => onChangeCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap flex-shrink-0 ${
                isActive
                  ? 'bg-emerald-400 text-black shadow-md shadow-emerald-500/30 font-extrabold scale-105'
                  : 'bg-[#131b26] text-gray-300 hover:text-emerald-300 hover:bg-[#1a2535] border border-emerald-950/60'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* ACTIVE CATEGORY FILTERED VIEW */}
      {isFilteredCategory ? (
        <section className="space-y-5">
          
          {/* Header Title Bar */}
          <div className="flex items-center justify-between border-b border-cyan-950/60 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-1.5 h-6 bg-cyan-400 rounded-full shadow-md shadow-cyan-500/50" />
              <h2 className="text-xl font-black text-white uppercase tracking-wider font-sans flex items-center gap-2">
                {activeCategory}
                {activeTranslatorName && (
                  <span className="text-xs text-cyan-400 font-normal normal-case">
                    ({activeTranslatorName})
                  </span>
                )}
              </h2>
            </div>
            <span className="text-xs text-gray-400 font-bold bg-gray-900 px-3 py-1 rounded-full border border-gray-800">
              {filteredMovies.length} Movies
            </span>
          </div>

          {/* TOP NOTICE / SUB-FILTER BUTTONS (Requested: "kuri body user nakanda kuri category nukaka nka series azajya abona top not button") */}
          <div className="bg-gradient-to-r from-[#0d1521] via-[#121e2e] to-[#0d1521] p-4 rounded-2xl border border-cyan-500/30 shadow-xl space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-xs tracking-wider uppercase">
                <BellRing className="w-4 h-4 text-cyan-400 animate-bounce" />
                <span>TOP NOTICE BUTTONS & FILTERS ({activeCategory.toUpperCase()})</span>
              </div>
              {subFilter !== 'all' && (
                <button
                  onClick={() => setSubFilter('all')}
                  className="text-[11px] font-bold text-gray-400 hover:text-cyan-300 underline"
                >
                  Reset Filter
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none flex-wrap">
              <button
                onClick={() => setSubFilter('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                  subFilter === 'all'
                    ? 'bg-cyan-400 text-black shadow-md shadow-cyan-500/30'
                    : 'bg-[#182333] text-gray-300 hover:text-white border border-cyan-900/50'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Filime Zose ({activeCategory})</span>
              </button>

              <button
                onClick={() => setSubFilter('top_rated')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                  subFilter === 'top_rated'
                    ? 'bg-amber-400 text-black shadow-md shadow-amber-500/30'
                    : 'bg-[#182333] text-gray-300 hover:text-white border border-cyan-900/50'
                }`}
              >
                <Star className="w-3.5 h-3.5 fill-current" />
                <span>🔥 Top Rated & Trending</span>
              </button>

              {activeCategory === 'Series' && (
                <>
                  {onSelectSeriesFolderView && (
                    <button
                      onClick={onSelectSeriesFolderView}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-extrabold bg-gradient-to-r from-emerald-400 to-teal-400 text-black shadow-md flex items-center gap-1.5 hover:brightness-110"
                    >
                      <Folder className="w-3.5 h-3.5 fill-black" />
                      <span>📂 View All Series Folders</span>
                    </button>
                  )}

                  <button
                    onClick={() => setSubFilter('korea')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                      subFilter === 'korea'
                        ? 'bg-cyan-400 text-black'
                        : 'bg-[#182333] text-gray-300 border border-cyan-900/50'
                    }`}
                  >
                    <span>🇰🇷 Korea Series</span>
                  </button>

                  <button
                    onClick={() => setSubFilter('american')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                      subFilter === 'american'
                        ? 'bg-cyan-400 text-black'
                        : 'bg-[#182333] text-gray-300 border border-cyan-900/50'
                    }`}
                  >
                    <span>🇺🇸 American Series</span>
                  </button>
                </>
              )}

              {(activeCategory === 'Agasobanuye' || activeCategory === 'New Movies' || activeCategory === 'Action') && (
                <>
                  <button
                    onClick={() => setSubFilter('rocky')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                      subFilter === 'rocky'
                        ? 'bg-cyan-400 text-black'
                        : 'bg-[#182333] text-gray-300 border border-cyan-900/50'
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span>Rocky Kimomo Dubs</span>
                  </button>

                  <button
                    onClick={() => setSubFilter('kabosio')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                      subFilter === 'kabosio'
                        ? 'bg-cyan-400 text-black'
                        : 'bg-[#182333] text-gray-300 border border-cyan-900/50'
                    }`}
                  >
                    <Film className="w-3.5 h-3.5 text-cyan-400" />
                    <span>VJ Kabosio Dubs</span>
                  </button>

                  <button
                    onClick={() => setSubFilter('sankara')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${
                      subFilter === 'sankara'
                        ? 'bg-cyan-400 text-black'
                        : 'bg-[#182333] text-gray-300 border border-cyan-900/50'
                    }`}
                  >
                    <Flame className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
                    <span>Sankara & Hakim</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {filteredMovies.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-5">
              {filteredMovies.map((movie) => (
                <MovieCard key={movie.id} movie={movie} onSelect={onSelectMovie} downloadsEnabled={downloadsEnabled} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-[#101722] rounded-2xl border border-cyan-950/50 p-6">
              <Sparkles className="w-10 h-10 text-cyan-500/40 mx-auto mb-3" />
              <p className="text-gray-300 text-sm font-semibold">Nta filime ibonetse muri iki cyiciro cha {activeCategory}.</p>
              <button
                onClick={() => {
                  onChangeCategory('All');
                  setSubFilter('all');
                }}
                className="mt-4 px-4 py-2 bg-cyan-400 text-black text-xs font-bold rounded-full hover:bg-cyan-300 transition-colors"
              >
                Reba Filime Zose
              </button>
            </div>
          )}
        </section>
      ) : (
        /* WELCOME PAGE DIVIDED INTO SECTIONS (New Movies, Agasobanuye, Series, Action, Drama, etc.) */
        <div className="space-y-12">
          {sectionsToDisplay.map((sec) => {
            const sectionMovies = getSectionMovies(sec.key);

            if (sectionMovies.length === 0) return null;

            return (
              <section key={sec.key} className="space-y-4">
                
                {/* Section Title Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-1.5 h-6 bg-emerald-400 rounded-full shadow-md shadow-emerald-500/50" />
                    <h2 className="text-lg sm:text-xl font-black text-white uppercase tracking-wider font-sans flex items-center gap-2">
                      {sec.title}
                      {activeTranslatorName && (
                        <span className="text-xs text-emerald-400 font-normal normal-case">
                          ({activeTranslatorName})
                        </span>
                      )}
                    </h2>
                    <span className="hidden sm:inline-flex px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                      {sec.badge}
                    </span>
                  </div>

                  <button
                    onClick={() => onChangeCategory(sec.key)}
                    className="text-xs font-extrabold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors uppercase tracking-wider"
                  >
                    View All ({sectionMovies.length}) <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Section Cards Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-5">
                  {sectionMovies.slice(0, 4).map((movie) => (
                    <MovieCard key={movie.id} movie={movie} onSelect={onSelectMovie} downloadsEnabled={downloadsEnabled} />
                  ))}
                </div>

              </section>
            );
          })}
        </div>
      )}

    </div>
  );
};
