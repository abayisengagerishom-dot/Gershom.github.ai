import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, Volume2, VolumeX, Clock, Sparkles, ChevronLeft, ChevronRight, Eye } from 'lucide-react';
import { TranslatorStatus } from '../types';

interface StatusViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  statuses: TranslatorStatus[];
  initialStatusIndex?: number;
}

export const StatusViewerModal: React.FC<StatusViewerModalProps> = ({
  isOpen,
  onClose,
  statuses,
  initialStatusIndex = 0
}) => {
  if (!isOpen || statuses.length === 0) return null;

  const [currentIndex, setCurrentIndex] = useState(initialStatusIndex);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const currentStatus = statuses[currentIndex] || statuses[0];

  // Reset video and progress when index changes
  useEffect(() => {
    setProgress(0);
    setIsPlaying(true);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => setIsMuted(true));
    }
  }, [currentIndex]);

  // Video time update handler
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const dur = videoRef.current.duration || 60;
      // Cap maximum status duration at 60 seconds (1 minute)
      const maxDur = Math.min(dur, 60);
      const cur = videoRef.current.currentTime;
      
      const currentProgress = (cur / maxDur) * 100;
      setProgress(Math.min(currentProgress, 100));

      if (cur >= maxDur) {
        handleNext();
      }
    }
  };

  const handleNext = () => {
    if (currentIndex < statuses.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    } else {
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
      }
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  // Format time ago and expiration
  const getTimeAgo = (createdAt: number) => {
    const diffHours = Math.floor((Date.now() - createdAt) / (1000 * 60 * 60));
    if (diffHours < 1) return 'Hivi karibu (Just now)';
    return `${diffHours}h ago`;
  };

  const getExpiresIn = (expiresAt: number) => {
    const remainingMs = expiresAt - Date.now();
    if (remainingMs <= 0) return 'Expired';
    const remainingHours = Math.floor(remainingMs / (1000 * 60 * 60));
    const remainingMins = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${remainingHours}h ${remainingMins}m remaining`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-0 sm:p-4 backdrop-blur-xl animate-fade-in">
      
      {/* Phone/Story Container */}
      <div className="relative w-full max-w-md h-full sm:h-[90vh] bg-black sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between border border-emerald-500/30">
        
        {/* TOP SEGMENTED PROGRESS BARS */}
        <div className="absolute top-0 left-0 right-0 z-30 p-3 pt-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
          <div className="flex gap-1.5 mb-3">
            {statuses.map((s, idx) => (
              <div key={s.id} className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-400 transition-all duration-100 ease-linear"
                  style={{
                    width: idx < currentIndex ? '100%' : idx === currentIndex ? `${progress}%` : '0%'
                  }}
                />
              </div>
            ))}
          </div>

          {/* STATUS HEADER INFO */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {/* Avatar with glowing green ring */}
              <div className="w-10 h-10 rounded-full p-0.5 bg-gradient-to-tr from-emerald-400 to-green-500 ring-2 ring-emerald-400/80 shadow-md">
                <img
                  src={currentStatus.translatorAvatar}
                  alt={currentStatus.translatorName}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>

              <div>
                <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                  {currentStatus.translatorName}
                  <span className="px-1.5 py-0.2 text-[9px] font-extrabold bg-emerald-500 text-black rounded">
                    STATUS 24H
                  </span>
                </h4>
                <div className="flex items-center gap-2 text-[10px] text-gray-300 font-semibold">
                  <span>{getTimeAgo(currentStatus.createdAt)}</span>
                  <span>•</span>
                  <span className="text-emerald-400 flex items-center gap-0.5">
                    <Clock className="w-2.5 h-2.5" />
                    {getExpiresIn(currentStatus.expiresAt)}
                  </span>
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={toggleMute}
                className="w-8 h-8 rounded-full bg-black/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-emerald-500 hover:text-black transition-colors"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              <button
                onClick={togglePlay}
                className="w-8 h-8 rounded-full bg-black/50 backdrop-blur-md text-white flex items-center justify-center hover:bg-emerald-500 hover:text-black transition-colors"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>

              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-red-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* TAP NAVIGATION OVERLAYS (LEFT & RIGHT) */}
        <div className="absolute inset-0 z-10 flex">
          <div onClick={handlePrev} className="w-1/3 h-full cursor-pointer opacity-0 hover:opacity-10 bg-gradient-to-r from-white to-transparent" />
          <div onClick={togglePlay} className="w-1/3 h-full cursor-pointer" />
          <div onClick={handleNext} className="w-2/3 h-full cursor-pointer opacity-0 hover:opacity-10 bg-gradient-to-l from-white to-transparent" />
        </div>

        {/* STATUS VIDEO ELEMENT */}
        <div className="relative w-full h-full flex items-center justify-center bg-black overflow-hidden">
          <video
            ref={videoRef}
            src={currentStatus.videoUrl}
            autoPlay
            playsInline
            muted={isMuted}
            onTimeUpdate={handleTimeUpdate}
            onEnded={handleNext}
            className="w-full h-full object-contain"
          />

          {/* PERMANENT WEBSITE WATERMARK OVERLAY - Bottom Left */}
          <div className="absolute bottom-16 left-3 z-30 pointer-events-none flex items-center gap-1.5 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-xl border border-emerald-500/60 text-white shadow-xl shadow-black/90">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-[11px] font-black tracking-wider text-emerald-400 uppercase">
              AFRIMOVIES
            </span>
          </div>
        </div>

        {/* BOTTOM CAPTION OVERLAY */}
        {currentStatus.caption && (
          <div className="absolute bottom-0 left-0 right-0 z-20 p-5 bg-gradient-to-t from-black/90 via-black/60 to-transparent">
            <div className="bg-[#111823]/80 backdrop-blur-md p-3.5 rounded-2xl border border-emerald-500/30 text-xs font-semibold text-white shadow-xl">
              <span className="text-emerald-400 font-extrabold mr-1">@{currentStatus.translatorName}:</span>
              {currentStatus.caption}
            </div>
            
            <p className="text-[10px] text-center text-gray-400 mt-2 font-mono">
              Status izamara amasaha 24 gusa (WhatsApp Status format) • Max 1 Minute
            </p>
          </div>
        )}

      </div>
    </div>
  );
};
