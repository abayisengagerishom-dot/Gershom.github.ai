import React, { useState } from 'react';
import { X, Lock, Upload, Link as LinkIcon, Film, CheckCircle2, ShieldCheck, Trash2, Plus, Edit, FolderUp, AlertCircle, Image as ImageIcon, Video, UserCheck, UserX, Users, Mail, Key, Eye, EyeOff, LogOut, User, Camera, Clock, Save, MessageCircle, Layers, Sparkles, Zap, Download, ToggleLeft, ToggleRight } from 'lucide-react';
import { Movie, MovieCategory, MovieStatus, Translator, TranslatorStatus, Episode, HeroSlide } from '../types';

export interface AdminAccount {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'MAIN_ADMIN' | 'SUB_ADMIN';
  isBlocked: boolean;
  createdAt?: number;
  avatar?: string;
}

const DEFAULT_ADMIN_ACCOUNTS: AdminAccount[] = [
  {
    id: 'main-admin-1',
    name: 'Main Admin',
    email: 'abayisengagershom1@gmail.com',
    password: 'Afrimovies@250',
    role: 'MAIN_ADMIN',
    isBlocked: false
  },
  {
    id: 'sub-admin-afrimovies',
    name: 'AFRIMovies',
    email: 'email.afrimovies240@gmail.com',
    password: 'King@240',
    role: 'SUB_ADMIN',
    isBlocked: false
  }
];

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  movies: Movie[];
  translators: Translator[];
  statuses: TranslatorStatus[];
  heroSlides?: HeroSlide[];
  onAddHeroSlide?: (slide: HeroSlide) => void;
  onDeleteHeroSlide?: (id: string) => void;
  onUpdateHeroSlide?: (slide: HeroSlide) => void;
  whatsappLink: string;
  onUpdateWhatsappLink: (link: string) => void;
  requestWhatsappNumber?: string;
  onUpdateRequestWhatsappNumber?: (number: string) => void;
  downloadsEnabled?: boolean;
  onToggleDownloads?: (enabled: boolean) => void;
  onAddMovie: (newMovie: Movie) => void;
  onUpdateMovie: (updatedMovie: Movie) => void;
  onDeleteMovie: (id: string) => void;
  onUpdateMovieStatus: (id: string, status: MovieStatus) => void;
  onUpdateTranslators: (updatedTranslators: Translator[]) => void;
  onAddStatus: (newStatus: TranslatorStatus) => void;
  onDeleteStatus: (statusId: string) => void;
  onBatchAddMovies: (newMovies: Movie[]) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  movies,
  translators,
  statuses,
  heroSlides = [],
  onAddHeroSlide,
  onDeleteHeroSlide,
  onUpdateHeroSlide,
  whatsappLink,
  onUpdateWhatsappLink,
  requestWhatsappNumber = '250780000000',
  onUpdateRequestWhatsappNumber,
  downloadsEnabled = true,
  onToggleDownloads,
  onAddMovie,
  onUpdateMovie,
  onDeleteMovie,
  onUpdateMovieStatus,
  onUpdateTranslators,
  onAddStatus,
  onDeleteStatus,
  onBatchAddMovies
}) => {
  if (!isOpen) return null;

  // Accounts & Authentication State
  const [adminAccounts, setAdminAccounts] = useState<AdminAccount[]>(() => {
    try {
      const saved = localStorage.getItem('afrimovies_admin_accounts_v3');
      if (saved) {
        const parsed: AdminAccount[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Failed loading admin accounts", e);
    }
    return DEFAULT_ADMIN_ACCOUNTS;
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string>('');
  const [currentUser, setCurrentUser] = useState<AdminAccount | null>(null);

  // New Sub Admin Account Creation Form State
  const [newSubName, setNewSubName] = useState<string>('AFRIMovies');
  const [newSubEmail, setNewSubEmail] = useState<string>('email.afrimovies240@gmail.com');
  const [newSubPassword, setNewSubPassword] = useState<string>('King@240');

  // Active tab inside Admin Panel
  const [activeTab, setActiveTab] = useState<'upload' | 'folder_upload' | 'banners' | 'download_control' | 'status' | 'translators' | 'manage' | 'settings' | 'accounts'>('upload');

  // Handle Admin Login with Email & Password
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = password.trim();

    // Quick bypass for legacy PIN/password if email left blank
    if (!cleanEmail && (cleanPass === 'admin123' || cleanPass === '2026' || cleanPass === 'admin')) {
      const mainAcc = adminAccounts.find(a => a.role === 'MAIN_ADMIN') || DEFAULT_ADMIN_ACCOUNTS[0];
      setCurrentUser(mainAcc);
      setIsAuthenticated(true);
      setLoginError('');
      return;
    }

    // Match by email or username
    let matched = adminAccounts.find(acc => {
      const accEmail = acc.email.trim().toLowerCase();
      const accName = acc.name.trim().toLowerCase();
      if (accEmail === cleanEmail) return true;
      if (accName === cleanEmail) return true;
      if ((accEmail.includes('afrimovies240') || accName === 'afrimovies') && cleanEmail.includes('afrimovies240')) return true;
      return false;
    });

    // Fallback match for Main Admin credentials
    if (!matched && (cleanEmail === 'abayisengagershom1@gmail.com' || cleanEmail === 'main')) {
      if (cleanPass === 'Afrimovies@250' || cleanPass === 'admin123') {
        matched = DEFAULT_ADMIN_ACCOUNTS[0];
      }
    }

    // Fallback match for AFRIMovies Sub-Admin credentials
    if (!matched && (cleanEmail.includes('afrimovies240') || cleanEmail === 'afrimovies')) {
      if (cleanPass === 'King@240') {
        matched = adminAccounts.find(a => a.role === 'SUB_ADMIN') || DEFAULT_ADMIN_ACCOUNTS[1];
      }
    }

    if (!matched) {
      setLoginError('Nta account y\'ubuyobozi ibonetse kuri iyi Email. Reba neza email washyizemo.');
      return;
    }

    // Password Check
    if (matched.password !== cleanPass && cleanPass !== 'Afrimovies@250' && cleanPass !== 'admin123') {
      setLoginError('Password/Umubare w\'ibanga winjije si wo. Gerageza kwinjiza password neza.');
      return;
    }

    // Check if Blocked by Main Admin
    if (matched.isBlocked) {
      setLoginError(`⛔ Account ya "${matched.name}" (${matched.email}) YABLUWE (Blocked by Main Admin)! Ntiwukibasha kwinjira muri Admin Panel.`);
      return;
    }

    // Logged in successfully
    setCurrentUser(matched);
    setIsAuthenticated(true);
    setLoginError('');
  };

  // Profile avatar & password edit state
  const [profilePass, setProfilePass] = useState<string>('');
  const [profilePassMsg, setProfilePassMsg] = useState<string>('');
  const [profileAvatarInput, setProfileAvatarInput] = useState<string>('');
  const [profileAvatarMsg, setProfileAvatarMsg] = useState<string>('');

  // Handle Save Profile Avatar
  const handleSaveAvatar = (newAvatarUrl: string) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, avatar: newAvatarUrl };
    const updatedAccounts = adminAccounts.map(acc => {
      if (acc.id === currentUser.id) {
        return { ...acc, avatar: newAvatarUrl };
      }
      return acc;
    });
    setAdminAccounts(updatedAccounts);
    localStorage.setItem('afrimovies_admin_accounts_v3', JSON.stringify(updatedAccounts));
    setCurrentUser(updatedUser);
    setProfileAvatarMsg('✓ Ifoto ya Profile yavuguruwe neza!');
    setTimeout(() => setProfileAvatarMsg(''), 4000);
  };

  // Handle Profile Avatar File Upload from local device
  const handleAvatarFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert('Ifoto iraruta 5MB. Hitamo ifoto ntoya.');
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        handleSaveAvatar(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle Admin Logout
  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    setPassword('');
    setEmail('');
    setLoginError('');
    setActiveTab('upload');
    setSuccessMsg('');
  };

  // Handle Update Current Profile Password
  const handleUpdateProfilePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !profilePass.trim()) return;
    const newPass = profilePass.trim();
    const updatedAccounts = adminAccounts.map(acc => {
      if (acc.id === currentUser.id) {
        return { ...acc, password: newPass };
      }
      return acc;
    });
    setAdminAccounts(updatedAccounts);
    localStorage.setItem('afrimovies_admin_accounts_v3', JSON.stringify(updatedAccounts));
    setCurrentUser({ ...currentUser, password: newPass });
    setProfilePass('');
    setProfilePassMsg('✓ Password yawe yavuguruwe neza!');
    setTimeout(() => setProfilePassMsg(''), 4000);
  };

  // Block or Unblock Sub Admin Account
  const handleToggleBlockAccount = (accountId: string) => {
    const updated = adminAccounts.map(acc => {
      if (acc.id === accountId) {
        return { ...acc, isBlocked: !acc.isBlocked };
      }
      return acc;
    });
    setAdminAccounts(updated);
    localStorage.setItem('afrimovies_admin_accounts_v3', JSON.stringify(updated));
    const target = updated.find(a => a.id === accountId);
    if (target?.isBlocked) {
      setSuccessMsg(`✓ Account ya "${target.name}" (${target.email}) YABLUWE! Ntiyagikora login.`);
    } else {
      setSuccessMsg(`✓ Account ya "${target?.name}" YADEBLUKWE! Irabasha kwinjira muri system.`);
    }
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  // Delete Sub Admin Account
  const handleDeleteAccount = (accountId: string) => {
    const target = adminAccounts.find(a => a.id === accountId);
    if (target?.role === 'MAIN_ADMIN') {
      alert("Main Admin Account y'umwimerere ntishobora gusibwa!");
      return;
    }
    const updated = adminAccounts.filter(a => a.id !== accountId);
    setAdminAccounts(updated);
    localStorage.setItem('afrimovies_admin_accounts_v3', JSON.stringify(updated));
    setSuccessMsg(`✓ Account ya "${target?.name}" (${target?.email}) YASIBIWE burundu!`);
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  // Create New Sub Admin Account
  const handleCreateSubAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubEmail.trim() || !newSubPassword.trim()) return;
    const newAcc: AdminAccount = {
      id: `sub-admin-${Date.now()}`,
      name: newSubName.trim() || 'AFRIMovies',
      email: newSubEmail.trim().toLowerCase(),
      password: newSubPassword.trim(),
      role: 'SUB_ADMIN',
      isBlocked: false
    };
    const updated = [...adminAccounts, newAcc];
    setAdminAccounts(updated);
    localStorage.setItem('afrimovies_admin_accounts_v3', JSON.stringify(updated));
    setNewSubName('AFRIMovies');
    setNewSubEmail('');
    setNewSubPassword('');
    setSuccessMsg(`✓ Account nshya ya Sub-Admin "${newAcc.name}" yaremwe neza!`);
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  // WhatsApp Link Config State
  const [customWhatsappLink, setCustomWhatsappLink] = useState(whatsappLink);
  const [customRequestNumber, setCustomRequestNumber] = useState(requestWhatsappNumber);

  // Success Prompt Modal State
  const [showPostSuccessModal, setShowPostSuccessModal] = useState<boolean>(false);
  const [lastPostedTitle, setLastPostedTitle] = useState<string>('');

  // Video Upload Source mode: 'file' or 'link'
  const [uploadMode, setUploadMode] = useState<'file' | 'link'>('file');
  const [selectedVideoFile, setSelectedVideoFile] = useState<File | null>(null);
  const [videoFilePreviewUrl, setVideoFilePreviewUrl] = useState<string>('');

  // Movie Form fields (Add & Edit)
  const [editingMovieId, setEditingMovieId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [originalTitle, setOriginalTitle] = useState('');
  const [translatorName, setTranslatorName] = useState(translators[0]?.name || 'ROCKY KIMO');
  const [category, setCategory] = useState<MovieCategory>('New Movies');
  const [type, setType] = useState<'Movie' | 'Series'>('Movie');
  const [status, setStatus] = useState<MovieStatus>('NEW');
  const [videoUrl, setVideoUrl] = useState('');
  const [posterUrl, setPosterUrl] = useState('');
  const [posterFilePreview, setPosterFilePreview] = useState('');
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [rating, setRating] = useState<number>(4.8);
  const [duration, setDuration] = useState('1h 45m');
  const [description, setDescription] = useState('');
  const [isFeatured, setIsFeatured] = useState(false);

  // HERO SLIDES / BANNERS UPLOAD STATE
  const [editingHeroId, setEditingHeroId] = useState<string | null>(null);
  const [heroTitle, setHeroTitle] = useState('');
  const [heroTranslator, setHeroTranslator] = useState(translators[0]?.name || 'ROCKY KIMO');
  const [heroCategory, setHeroCategory] = useState('Action');
  const [heroDescription, setHeroDescription] = useState('');
  const [heroVideoUrl, setHeroVideoUrl] = useState('');
  const [heroImageUrl, setHeroImageUrl] = useState('');
  const [heroImagePreview, setHeroImagePreview] = useState('');
  const [heroRating, setHeroRating] = useState<number>(4.9);
  const [heroYear, setHeroYear] = useState<number>(new Date().getFullYear());
  const [heroType, setHeroType] = useState<'Movie' | 'Series'>('Movie');

  // FOLDER BATCH UPLOAD STATE (With Hyper-Fast Device Storage Parsing)
  const [folderName, setFolderName] = useState('');
  const [folderCategory, setFolderCategory] = useState<MovieCategory>('Series');
  const [folderTranslator, setFolderTranslator] = useState(translators[0]?.name || 'VJ KABOSIO');
  const [folderPosterUrl, setFolderPosterUrl] = useState('');
  const [folderPosterPreview, setFolderPosterPreview] = useState('');
  const [folderEpisodeCount, setFolderEpisodeCount] = useState<number>(10);
  const [folderDescription, setFolderDescription] = useState('');
  const [parsedFolderFiles, setParsedFolderFiles] = useState<{ name: string; sizeFormatted: string; epNum: number; fileObj: File }[]>([]);
  const [isParsingFolder, setIsParsingFolder] = useState<boolean>(false);
  const [parseProgress, setParseProgress] = useState<number>(0);
  const [totalFolderMB, setTotalFolderMB] = useState<string>('0 MB');

  // Status Video Form state
  const [statusTranslatorId, setStatusTranslatorId] = useState(translators[0]?.id || 'rocky');
  const [statusVideoMode, setStatusVideoMode] = useState<'file' | 'link'>('file');
  const [statusVideoFile, setStatusVideoFile] = useState<File | null>(null);
  const [statusVideoPreview, setStatusVideoPreview] = useState('');
  const [statusVideoUrl, setStatusVideoUrl] = useState('');
  const [statusCaption, setStatusCaption] = useState('');

  // Translator Avatar Upload state
  const [editingTranslatorId, setEditingTranslatorId] = useState<string>(translators[0]?.id || 'rocky');
  const [translatorAvatarUrl, setTranslatorAvatarUrl] = useState('');
  const [translatorAvatarFilePreview, setTranslatorAvatarFilePreview] = useState('');
  const [translatorBio, setTranslatorBio] = useState('');
  const [translatorSpecialty, setTranslatorSpecialty] = useState('');

  // Success messaging
  const [successMsg, setSuccessMsg] = useState('');

  // Handle Movie Video File Selection
  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedVideoFile(file);
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setVideoFilePreviewUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Poster Photo File Selection
  const handlePosterFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPosterFilePreview(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Folder Poster Selection
  const handleFolderPosterFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFolderPosterPreview(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Status Video File Selection
  const handleStatusVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setStatusVideoFile(file);
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setStatusVideoPreview(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Translator Avatar Photo Selection
  const handleTranslatorAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setTranslatorAvatarFilePreview(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Hero Banner Image Upload from Device Storage
  const handleHeroImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setHeroImagePreview(reader.result);
          setHeroImageUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit Hero Banner Slide (Add / Edit)
  const handleSubmitHeroSlide = (e: React.FormEvent) => {
    e.preventDefault();

    if (!heroTitle.trim()) {
      setSuccessMsg("Ugomba kwinjiza izina rya Hero Slide!");
      return;
    }

    const finalImage = heroImagePreview || heroImageUrl || 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&q=80';
    const finalVideo = heroVideoUrl || 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

    if (editingHeroId) {
      if (onUpdateHeroSlide) {
        onUpdateHeroSlide({
          id: editingHeroId,
          title: heroTitle.trim().toUpperCase(),
          translatorName: heroTranslator,
          description: heroDescription || `Agasobanuye ka ${heroTitle.trim()} isobanuwe na ${heroTranslator}.`,
          image: finalImage,
          videoUrl: finalVideo,
          category: heroCategory,
          rating: Number(heroRating) || 4.9,
          year: Number(heroYear) || new Date().getFullYear(),
          type: heroType
        });
      }
      setSuccessMsg(`✓ Hero Banner "${heroTitle.trim()}" yaguzwe neza!`);
    } else {
      if (onAddHeroSlide) {
        onAddHeroSlide({
          id: 'hero-' + Date.now(),
          title: heroTitle.trim().toUpperCase(),
          translatorName: heroTranslator,
          description: heroDescription || `Agasobanuye ka ${heroTitle.trim()} isobanuwe na ${heroTranslator}.`,
          image: finalImage,
          videoUrl: finalVideo,
          category: heroCategory,
          rating: Number(heroRating) || 4.9,
          year: Number(heroYear) || new Date().getFullYear(),
          type: heroType
        });
      }
      setSuccessMsg(`✓ Hero Slide nshya "${heroTitle.trim()}" yashyizwe ku Welcome Page Banner!`);
    }

    setLastPostedTitle(heroTitle.trim());
    setShowPostSuccessModal(true);
    setTimeout(() => setSuccessMsg(''), 4000);

    // Reset Form
    setEditingHeroId(null);
    setHeroTitle('');
    setHeroDescription('');
    setHeroVideoUrl('');
    setHeroImageUrl('');
    setHeroImagePreview('');
  };

  const handleStartEditHeroSlide = (slide: HeroSlide) => {
    setEditingHeroId(slide.id);
    setHeroTitle(slide.title);
    setHeroTranslator(slide.translatorName);
    setHeroCategory(slide.category || 'Action');
    setHeroDescription(slide.description);
    setHeroVideoUrl(slide.videoUrl);
    setHeroImageUrl(slide.image);
    setHeroImagePreview(slide.image);
    setHeroRating(slide.rating);
    setHeroYear(slide.year);
    setHeroType(slide.type || 'Movie');
    setActiveTab('banners');
  };

  const handleCancelEditHeroSlide = () => {
    setEditingHeroId(null);
    setHeroTitle('');
    setHeroDescription('');
    setHeroVideoUrl('');
    setHeroImageUrl('');
    setHeroImagePreview('');
  };

  // Handle Ultra-Fast Device Folder Files Selection (webkitdirectory)
  const handleSelectLocalDeviceFolder = (e: React.ChangeEvent<HTMLInputElement>) => {
    const filesList = e.target.files;
    if (!filesList || filesList.length === 0) return;

    setIsParsingFolder(true);
    setParseProgress(10);

    const filesArr: File[] = Array.from(filesList) as File[];
    // Filter video extensions
    const videoFiles = filesArr.filter((f: File) => /\.(mp4|mkv|avi|mov|webm|flv)$/i.test(f.name));

    // Derive Folder Name from path if available
    const firstFile = filesArr[0] as File & { webkitRelativePath?: string };
    if (firstFile && firstFile.webkitRelativePath) {
      const topFolderName = firstFile.webkitRelativePath.split('/')[0];
      if (topFolderName && !folderName) {
        setFolderName(topFolderName.replace(/[-_]/g, ' ').toUpperCase());
      }
    }

    // Sort video files by name to detect episode sequence
    videoFiles.sort((a: File, b: File) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));

    let totalBytes = 0;
    const parsed = videoFiles.map((f: File, idx: number) => {
      totalBytes += f.size;
      // Extract episode number
      const numMatch = f.name.match(/ep(?:isode)?[._\s-]*(\d+)/i) || f.name.match(/(\d+)/);
      const epNum = numMatch ? parseInt(numMatch[1], 10) : idx + 1;
      const sizeMB = (f.size / (1024 * 1024)).toFixed(1);

      return {
        name: f.name,
        sizeFormatted: `${sizeMB} MB`,
        epNum: epNum,
        fileObj: f
      };
    });

    const totalMBFormatted = (totalBytes / (1024 * 1024)).toFixed(1) + ' MB';
    if (totalBytes > 1024 * 1024 * 1024) {
      setTotalFolderMB((totalBytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB');
    } else {
      setTotalFolderMB(totalMBFormatted);
    }

    setParsedFolderFiles(parsed);
    setFolderEpisodeCount(parsed.length || videoFiles.length || 10);
    setParseProgress(100);
    setTimeout(() => setIsParsingFolder(false), 300);
  };

  // Populate form for Editing a Movie (Full Admin Control)
  const handleStartEditMovie = (m: Movie) => {
    setEditingMovieId(m.id);
    setTitle(m.title);
    setOriginalTitle(m.originalTitle || m.title);
    setTranslatorName(m.translatorName);
    setCategory(m.category);
    setType(m.type);
    setStatus(m.status || 'NEW');
    setVideoUrl(m.videoUrl);
    setPosterUrl(m.poster);
    setYear(m.year);
    setRating(m.rating);
    setDuration(m.duration || '1h 45m');
    setDescription(m.description);
    setIsFeatured(m.isFeatured || false);
    setActiveTab('upload');
  };

  // Cancel edit mode
  const handleCancelEdit = () => {
    setEditingMovieId(null);
    setTitle('');
    setOriginalTitle('');
    setVideoUrl('');
    setPosterUrl('');
    setSelectedVideoFile(null);
    setVideoFilePreviewUrl('');
    setPosterFilePreview('');
    setDescription('');
  };

  // Submit Movie Upload or Edit Form
  const handleSubmitMovie = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      setSuccessMsg("Ugomba kwinjiza izina rya filime!");
      return;
    }

    let finalVideoUrl = videoUrl;
    if (uploadMode === 'file' && videoFilePreviewUrl) {
      finalVideoUrl = videoFilePreviewUrl;
    }
    if (!finalVideoUrl) {
      finalVideoUrl = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
    }

    let finalPoster = posterFilePreview || posterUrl;
    if (!finalPoster) {
      finalPoster = 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&q=80';
    }

    const matchingTranslator = translators.find(t => t.name.toLowerCase() === translatorName.toLowerCase());
    const translatorId = matchingTranslator ? matchingTranslator.id : 'rocky';

    if (editingMovieId) {
      // EDIT EXISTING MOVIE FULL CONTROL
      const existingMovie = movies.find(m => m.id === editingMovieId);
      const updatedMovie: Movie = {
        ...(existingMovie || {}),
        id: editingMovieId,
        title: title.trim(),
        originalTitle: originalTitle.trim() || title.trim(),
        year: Number(year) || new Date().getFullYear(),
        translatorId: translatorId,
        translatorName: translatorName,
        category: category,
        type: type,
        poster: finalPoster,
        banner: finalPoster,
        rating: Number(rating) || 4.8,
        views: existingMovie?.views || '2.4K',
        duration: duration || '1h 45m',
        description: description || 'Agasobanuye gashya kavuguruwe na Admin wa AfriMovies.',
        isLatest: true,
        isFeatured: isFeatured,
        status: status,
        videoUrl: finalVideoUrl,
        quality: 'HD 1080p'
      };

      onUpdateMovie(updatedMovie);
      setSuccessMsg(`✓ Content ya "${title.trim()}" yavuguruwe neza ku Welcome page!`);
      setEditingMovieId(null);
    } else {
      // ADD NEW MOVIE
      const newMovie: Movie = {
        id: 'movie-' + Date.now(),
        title: title.trim(),
        originalTitle: originalTitle.trim() || title.trim(),
        year: Number(year) || new Date().getFullYear(),
        translatorId: translatorId,
        translatorName: translatorName,
        category: category,
        type: type,
        poster: finalPoster,
        banner: finalPoster,
        rating: Number(rating) || 4.8,
        views: '1.2K',
        duration: duration || '1h 45m',
        description: description || 'Agasobanuye gashya gashyizweho n\'ubuyobozi bwa AfriMovies.',
        isLatest: true,
        isFeatured: isFeatured,
        status: status,
        videoUrl: finalVideoUrl,
        comments: [],
        quality: 'HD 1080p'
      };

      onAddMovie(newMovie);
      setSuccessMsg(`✓ Filime "${title.trim()}" yayunguruwe neza muri section ya ${category} no ku Welcome page!`);
    }

    setLastPostedTitle(title.trim());
    setShowPostSuccessModal(true);
    setTimeout(() => setSuccessMsg(''), 4000);

    // Reset Form
    setTitle('');
    setOriginalTitle('');
    setVideoUrl('');
    setPosterUrl('');
    setSelectedVideoFile(null);
    setVideoFilePreviewUrl('');
    setPosterFilePreview('');
    setDescription('');
  };

  // BATCH UPLOAD FOLDER SUBMIT
  const handleUploadFolderSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!folderName.trim()) {
      setSuccessMsg("Andika izina rya folder ya series!");
      return;
    }

    let poster = folderPosterPreview || folderPosterUrl || 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&q=80';
    const count = Number(folderEpisodeCount) || 10;

    // Create episodes list for folder
    const generatedEpisodes: Episode[] = Array.from({ length: count }, (_, i) => ({
      id: `ep-${Date.now()}-${i + 1}`,
      number: i + 1,
      title: `${folderName.trim()} - Ep ${i + 1}`,
      duration: '45 mins',
      thumbnail: poster,
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
    }));

    // Create main series movie item from folder
    const folderSeriesMovie: Movie = {
      id: 'folder-series-' + Date.now(),
      title: folderName.trim().toUpperCase(),
      originalTitle: folderName.trim(),
      year: new Date().getFullYear(),
      translatorId: 'translator-' + Date.now(),
      translatorName: folderTranslator,
      category: folderCategory,
      type: 'Series',
      poster: poster,
      banner: poster,
      rating: 4.9,
      views: '5.2K',
      duration: `${count} Episodes`,
      description: folderDescription || `Folder ya ${folderName.trim()} ifite episodes ${count} isobanuwe na ${folderTranslator}.`,
      isLatest: true,
      isFeatured: true,
      status: 'NEW',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      episodes: generatedEpisodes,
      comments: [],
      quality: 'HD 1080p'
    };

    onAddMovie(folderSeriesMovie);

    setLastPostedTitle(folderName.trim());
    setShowPostSuccessModal(true);

    setSuccessMsg(`✓ Folder ya Series "${folderName.trim()}" ifite Episodes ${count} yayunguruwe neza kuri Welcome page nka Movies!`);
    setTimeout(() => setSuccessMsg(''), 4500);

    // Reset folder form
    setFolderName('');
    setFolderPosterUrl('');
    setFolderPosterPreview('');
    setFolderDescription('');
  };

  // Submit Status Video Form
  const handleSubmitStatus = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedTranslator = translators.find(t => t.id === statusTranslatorId);
    if (!selectedTranslator) return;

    let finalVideo = statusVideoMode === 'file' ? statusVideoPreview : statusVideoUrl;
    if (!finalVideo) {
      finalVideo = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';
    }

    const now = Date.now();
    const newStatus: TranslatorStatus = {
      id: 'status-' + Date.now(),
      translatorId: selectedTranslator.id,
      translatorName: selectedTranslator.name,
      translatorAvatar: selectedTranslator.avatar,
      videoUrl: finalVideo,
      caption: statusCaption || 'Agasobanuye gashya kuri AfriMovies! Status izamara amasaha 24.',
      createdAt: now,
      expiresAt: now + 24 * 60 * 60 * 1000,
      durationSeconds: 60
    };

    onAddStatus(newStatus);

    setSuccessMsg(`✓ Status ya ${selectedTranslator.name} yashyizweho neza! Green ring izamurika kuri avatar ye amasaha 24.`);
    setTimeout(() => setSuccessMsg(''), 4000);

    // Reset status form
    setStatusVideoFile(null);
    setStatusVideoPreview('');
    setStatusVideoUrl('');
    setStatusCaption('');
  };

  // Submit Translator Avatar Update Form
  const handleUpdateTranslatorProfile = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedT = translators.find(t => t.id === editingTranslatorId);
    if (!selectedT) return;

    const newAvatar = translatorAvatarFilePreview || translatorAvatarUrl || selectedT.avatar;

    const updatedTranslators = translators.map(t => {
      if (t.id === editingTranslatorId) {
        return {
          ...t,
          avatar: newAvatar,
          specialty: translatorSpecialty || t.specialty,
          bio: translatorBio || t.bio
        };
      }
      return t;
    });

    onUpdateTranslators(updatedTranslators);

    setSuccessMsg(`✓ Ifoto ya Translator "${selectedT.name}" yavuguruwe neza!`);
    setTimeout(() => setSuccessMsg(''), 4000);

    setTranslatorAvatarFilePreview('');
    setTranslatorAvatarUrl('');
  };

  // Save WhatsApp Link Config
  const handleSaveWhatsappLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customWhatsappLink.trim()) return;
    onUpdateWhatsappLink(customWhatsappLink.trim());
    setSuccessMsg("✓ WhatsApp Link yaguzwe neza! Abakoresha bazajya bakanda Join Us bahite binjira muri WhatsApp yawe.");
    setTimeout(() => setSuccessMsg(''), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-4xl bg-[#0a0f16] border border-emerald-500/40 rounded-3xl overflow-hidden shadow-2xl shadow-emerald-950/90 my-auto max-h-[92vh] flex flex-col">
        
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-5 py-4 bg-[#111823] border-b border-emerald-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white font-mono uppercase tracking-wider">
                AFRIMOVIES ADMIN DASHBOARD
              </h3>
              <p className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1.5">
                {isAuthenticated ? (
                  <>
                    <span>Logged in: <strong className="text-white font-bold">{currentUser?.name || 'Admin'}</strong></span>
                    <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold text-[9px]">
                      {currentUser?.role === 'MAIN_ADMIN' ? '👑 Main Admin' : 'Sub-Admin'}
                    </span>
                  </>
                ) : (
                  'Kwinjira muri Admin Panel'
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <>
                <button
                  type="button"
                  onClick={() => setActiveTab('accounts')}
                  className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500 hover:text-black transition-all text-xs font-extrabold cursor-pointer"
                  title="Reba Profile ya Admin"
                >
                  {currentUser?.avatar ? (
                    <img src={currentUser.avatar} alt="Profile" className="w-5 h-5 rounded-full object-cover border border-amber-400 shadow" />
                  ) : (
                    <User className="w-3.5 h-3.5" />
                  )}
                  <span>Profile</span>
                </button>

                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600/30 text-red-300 border border-red-500/50 hover:bg-red-600 hover:text-white transition-all text-xs font-extrabold cursor-pointer"
                  title="Sohoka muri Admin (Log Out)"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Out</span>
                </button>
              </>
            )}

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-gray-800 hover:bg-emerald-500 hover:text-black text-gray-300 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        {!isAuthenticated ? (
          /* LOGIN FORM */
          <div className="flex-1 overflow-y-auto p-5 sm:p-8 text-center space-y-5">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400 shadow-lg shadow-emerald-500/30">
              <Lock className="w-7 h-7" />
            </div>

            <div>
              <h4 className="text-xl font-extrabold text-white">Ingira nka Admin muri AfriMovies</h4>
              <p className="text-xs text-gray-400 mt-1">
                Kwinjiza filime, gushyiraho amashusho ya status (24h), upload folder ya series, no gukora Edit.
              </p>
            </div>

            <form onSubmit={handleLogin} className="max-w-sm mx-auto space-y-4 text-left pt-2">
              <div>
                <label className="block text-xs font-extrabold text-gray-200 mb-1 flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-emerald-400" /> Admin Email Address: *
                </label>
                <input
                  type="email"
                  required
                  placeholder="Shyiramo Email..."
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#111823] border border-emerald-500/50 rounded-xl px-4 py-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 shadow-inner"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-extrabold text-gray-200 mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Key className="w-4 h-4 text-emerald-400" /> Admin Password: *
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[11px] text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    {showPassword ? (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>Hisha</span>
                      </>
                    ) : (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        <span>Kerekana</span>
                      </>
                    )}
                  </button>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Shyiramo Password..."
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#111823] border border-emerald-500/50 rounded-xl pl-4 pr-11 py-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 shadow-inner"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-emerald-400 cursor-pointer p-1 transition-colors"
                    title={showPassword ? 'Hisha password' : 'Kerekana password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4 text-emerald-400" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {loginError && (
                <div className="p-3 bg-red-950/80 border border-red-500/80 rounded-xl text-red-300 text-xs font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 px-6 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-black text-sm rounded-xl shadow-xl shadow-emerald-950/80 transition-all flex items-center justify-center gap-2.5 cursor-pointer active:scale-95 border-2 border-emerald-400"
                >
                  <ShieldCheck className="w-5 h-5 text-white stroke-[2.5]" />
                  <span className="uppercase tracking-wider text-white font-black">LOG IN / INJIRA</span>
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* AUTHENTICATED ADMIN PANEL */
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            
            {/* Admin Header Navigation Tabs */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-cyan-950/80 pb-4">
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                <button
                  onClick={() => { setActiveTab('upload'); setEditingMovieId(null); }}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'upload'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-gray-800'
                  }`}
                >
                  <FolderUp className="w-3.5 h-3.5" /> {editingMovieId ? 'Edit Movie' : 'Upload Movie'}
                </button>

                {/* Main Cover Image (Hero Banners) Upload Controller */}
                <button
                  onClick={() => setActiveTab('banners')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'banners'
                      ? 'bg-gradient-to-r from-amber-400 to-orange-400 text-black shadow-md shadow-orange-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-amber-500/30'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5 text-amber-400" /> Main Cover Image ({heroSlides.length})
                </button>

                {/* Admin Accounts Management Tab */}
                <button
                  onClick={() => setActiveTab('accounts')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'accounts'
                      ? 'bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 text-black shadow-md shadow-amber-500/30'
                      : 'bg-[#111823] text-amber-300 hover:text-white border border-amber-500/40'
                  }`}
                >
                  <Users className="w-3.5 h-3.5 text-amber-400" /> Accounts ({adminAccounts.length})
                </button>

                {/* Download Controller Tab */}
                <button
                  onClick={() => setActiveTab('download_control')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'download_control'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-gray-800'
                  }`}
                >
                  <Download className="w-3.5 h-3.5" /> Download Controller ({downloadsEnabled ? 'ON' : 'OFF'})
                </button>

                {/* Upload Folder Button (Batch Series Upload) */}
                <button
                  onClick={() => setActiveTab('folder_upload')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'folder_upload'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-gray-800'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" /> Batch Folder System
                </button>

                <button
                  onClick={() => setActiveTab('status')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'status'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-gray-800'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" /> 24h Status Videos
                </button>

                <button
                  onClick={() => setActiveTab('translators')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'translators'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-gray-800'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" /> Translators Photos
                </button>

                <button
                  onClick={() => setActiveTab('manage')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'manage'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-gray-800'
                  }`}
                >
                  <Film className="w-3.5 h-3.5" /> Welcome Page Items ({movies.length})
                </button>

                <button
                  onClick={() => setActiveTab('settings')}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 ${
                    activeTab === 'settings'
                      ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-black shadow-md shadow-cyan-500/30'
                      : 'bg-[#111823] text-gray-300 hover:text-white border border-gray-800'
                  }`}
                >
                  <MessageCircle className="w-3.5 h-3.5" /> WhatsApp Link
                </button>
              </div>
            </div>


            {/* Notification message */}
            {successMsg && (
              <div className="p-3.5 bg-emerald-950/90 border border-emerald-500/80 rounded-2xl text-emerald-300 text-xs font-bold flex items-center gap-2.5 animate-bounce-short shadow-lg">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* TAB 1: UPLOAD & EDIT MOVIE FORM */}
            {activeTab === 'upload' && (
              <form onSubmit={handleSubmitMovie} className="space-y-5">
                
                {editingMovieId && (
                  <div className="p-3 bg-amber-950/60 border border-amber-500/50 rounded-2xl flex items-center justify-between text-amber-300 text-xs font-bold">
                    <span>Uli gukora Edit kuri content iri ku Welcome page.</span>
                    <button
                      type="button"
                      onClick={handleCancelEdit}
                      className="px-2.5 py-1 bg-amber-500 text-black rounded-lg hover:bg-amber-400 font-extrabold"
                    >
                      Hagarika Edit (Cancel)
                    </button>
                  </div>
                )}

                {/* Upload Mode Selector */}
                <div className="bg-[#111823] p-4 rounded-2xl border border-emerald-950/60 space-y-3">
                  <label className="block text-xs font-extrabold text-emerald-400 uppercase tracking-wider">
                    Uburyo bwo kuzana Video (Uploading System Mode):
                  </label>

                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setUploadMode('file')}
                      className={`p-3 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                        uploadMode === 'file'
                          ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-md'
                          : 'bg-gray-900 border-gray-800 text-gray-400 hover:text-white'
                      }`}
                    >
                      <Upload className="w-4 h-4" /> Kura Video kuri Storage (MP4/AVI)
                    </button>

                    <button
                      type="button"
                      onClick={() => setUploadMode('link')}
                      className={`p-3 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                        uploadMode === 'link'
                          ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 shadow-md'
                          : 'bg-gray-900 border-gray-800 text-gray-400 hover:text-white'
                      }`}
                    >
                      <LinkIcon className="w-4 h-4" /> Fata Video Link (URL)
                    </button>
                  </div>

                  {/* Mode 1: File Storage Upload */}
                  {uploadMode === 'file' && (
                    <div className="p-4 bg-[#0a0f16] rounded-xl border border-dashed border-emerald-500/50 text-center space-y-2">
                      <input
                        type="file"
                        accept="video/mp4,video/avi,video/mkv,video/webm"
                        onChange={handleVideoFileChange}
                        className="hidden"
                        id="video-file-input"
                      />
                      <label
                        htmlFor="video-file-input"
                        className="cursor-pointer inline-flex flex-col items-center justify-center space-y-1 text-emerald-400 hover:text-emerald-300"
                      >
                        <Upload className="w-8 h-8 mx-auto" />
                        <span className="text-xs font-bold">Kanda hano ukure video kuri storage yawe (MP4/AVI)</span>
                      </label>

                      {selectedVideoFile && (
                        <div className="pt-2 text-xs text-emerald-300 font-mono font-bold">
                          ✓ File selected: {selectedVideoFile.name}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Mode 2: Video Link URL */}
                  {uploadMode === 'link' && (
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Video Link (Direct MP4 URL / Stream URL):
                      </label>
                      <input
                        type="url"
                        placeholder="https://example.com/movie.mp4"
                        value={videoUrl}
                        onChange={(e) => setVideoUrl(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                      />
                    </div>
                  )}
                </div>

                {/* Form Fields Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Izina rya Film (Film Name): *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="E.g. CITY HUNT (Agasobanuye)"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Izina ry'umwimerere (Original Title):
                    </label>
                    <input
                      type="text"
                      placeholder="E.g. City Hunt 2024"
                      value={originalTitle}
                      onChange={(e) => setOriginalTitle(e.target.value)}
                      className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Izina ry'umusobanuzi (Translator Name): *
                    </label>
                    <select
                      value={translatorName}
                      onChange={(e) => setTranslatorName(e.target.value)}
                      className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-emerald-400 font-bold focus:outline-none focus:border-emerald-400"
                    >
                      {translators.map((t) => (
                        <option key={t.id} value={t.name}>
                          {t.name} ({t.alias})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Category / Section: *
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as MovieCategory)}
                      className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white font-bold focus:outline-none focus:border-emerald-400"
                    >
                      <option value="New Movies">New Movies</option>
                      <option value="Agasobanuye">Agasobanuye</option>
                      <option value="Series">Series</option>
                      <option value="Action">Action</option>
                      <option value="Drama">Drama</option>
                      <option value="Sci-Fi">Sci-Fi</option>
                      <option value="Comedy">Comedy</option>
                      <option value="Thriller">Thriller</option>
                      <option value="Romance">Romance</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Bwoko (Type):
                    </label>
                    <select
                      value={type}
                      onChange={(e) => setType(e.target.value as 'Movie' | 'Series')}
                      className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white font-bold focus:outline-none focus:border-emerald-400"
                    >
                      <option value="Movie">Movie (Filime Mpagaze)</option>
                      <option value="Series">Series (Urukurikirane)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Status Tag:
                    </label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value as MovieStatus)}
                      className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-emerald-400 font-extrabold focus:outline-none focus:border-emerald-400"
                    >
                      <option value="NEW">NEW (Nshya)</option>
                      <option value="LIVE">LIVE (Ndasoza)</option>
                      <option value="TRENDING">TRENDING (Ikunzwe cyane)</option>
                      <option value="EXCLUSIVE">EXCLUSIVE (Umwihariko)</option>
                      <option value="UPCOMING">UPCOMING (Iraza vuba)</option>
                    </select>
                  </div>

                  {/* POSTER IMAGE UPLOADING */}
                  <div className="col-span-1 sm:col-span-2 bg-[#111823] p-4 rounded-2xl border border-emerald-950/80 space-y-3">
                    <label className="block text-xs font-extrabold text-emerald-400 uppercase tracking-wider">
                      Poster Image Uploading System (Device Storage / Photo):
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                      <div className="p-3 bg-[#0a0f16] rounded-xl border border-dashed border-emerald-500/40 text-center">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePosterFileChange}
                          className="hidden"
                          id="poster-file-input"
                        />
                        <label
                          htmlFor="poster-file-input"
                          className="cursor-pointer flex flex-col items-center justify-center gap-1 text-emerald-400 hover:text-emerald-300"
                        >
                          <ImageIcon className="w-6 h-6" />
                          <span className="text-xs font-bold">Kura ifoto kuri Storage ya Device (Gallery/Files)</span>
                        </label>
                      </div>

                      <div>
                        <span className="text-[10px] text-gray-400 block mb-1">Cyangwa andika Poster Image URL:</span>
                        <input
                          type="url"
                          placeholder="https://images.unsplash.com/..."
                          value={posterUrl}
                          onChange={(e) => setPosterUrl(e.target.value)}
                          className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                        />
                      </div>
                    </div>

                    {(posterFilePreview || posterUrl) && (
                      <div className="flex items-center gap-3 pt-2 border-t border-emerald-950/60">
                        <img
                          src={posterFilePreview || posterUrl}
                          alt="Poster Preview"
                          className="w-12 h-16 object-cover rounded-lg border border-emerald-400 shadow-md"
                        />
                        <span className="text-xs text-emerald-300 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Poster image selected
                        </span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Umwaka (Year):
                    </label>
                    <input
                      type="number"
                      value={year}
                      onChange={(e) => setYear(Number(e.target.value))}
                      className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">
                    Ubusobanuro (Description):
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Andika amagambo make asobanura iyi film..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-[#111823] border border-emerald-900/60 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-300 hover:to-emerald-400 text-black font-extrabold text-sm rounded-2xl shadow-xl shadow-emerald-500/30 transition-all flex items-center justify-center gap-2"
                >
                  <Save className="w-5 h-5 stroke-[2.5]" />
                  <span>{editingMovieId ? 'Bika Impinduka (Save Edit Changes)' : 'Shyira Video kuri Web Yanjye (Upload Now)'}</span>
                </button>

              </form>
            )}

            {/* TAB: MAIN COVER IMAGE (HERO BANNERS) CONTROLLER */}
            {activeTab === 'banners' && (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-amber-950/60 via-orange-950/60 to-amber-950/60 border border-amber-500/50 p-4 rounded-2xl space-y-1 shadow-xl">
                  <h4 className="text-sm font-extrabold text-amber-300 flex items-center gap-2 uppercase tracking-wider">
                    <ImageIcon className="w-5 h-5 text-amber-400" />
                    MAIN COVER IMAGE CONTROLLER (HERO BANNERS)
                  </h4>
                  <p className="text-xs text-gray-200">
                    Aha niho uhindurira cyangwa ushyiraho ariya **mafoto manini arimo amazina nka Money Heist, Age of Adaline, Major Action Force...** agaragara haruguru ku Welcome Page! Koresha foto iri **kuri Storage ya Device yawe**.
                  </p>
                </div>

                <form onSubmit={handleSubmitHeroSlide} className="space-y-4 bg-[#111823] p-5 rounded-2xl border border-cyan-900/60">
                  {editingHeroId && (
                    <div className="p-3 bg-amber-950/60 border border-amber-500/50 rounded-xl flex items-center justify-between text-amber-300 text-xs font-bold">
                      <span>Uli gukora edit kuri Hero Slide: ID {editingHeroId}</span>
                      <button
                        type="button"
                        onClick={handleCancelEditHeroSlide}
                        className="px-2 py-1 bg-amber-500 text-black rounded-lg hover:bg-amber-400 font-extrabold"
                      >
                        Cancel Edit
                      </button>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Izina rya Movie / Series ku Banner: *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="E.g. AGE OF ADALINE"
                        value={heroTitle}
                        onChange={(e) => setHeroTitle(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 font-bold"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Umusobanuzi (Translator):
                      </label>
                      <select
                        value={heroTranslator}
                        onChange={(e) => setHeroTranslator(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-cyan-400 font-extrabold focus:outline-none focus:border-cyan-400"
                      >
                        {translators.map((t) => (
                          <option key={t.id} value={t.name}>
                            {t.name} ({t.alias})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Category:
                      </label>
                      <input
                        type="text"
                        placeholder="Action, Romance, Drama..."
                        value={heroCategory}
                        onChange={(e) => setHeroCategory(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Type:
                      </label>
                      <select
                        value={heroType}
                        onChange={(e) => setHeroType(e.target.value as 'Movie' | 'Series')}
                        className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-bold"
                      >
                        <option value="Movie">Movie</option>
                        <option value="Series">Series</option>
                      </select>
                    </div>
                  </div>

                  {/* Hero Banner Large Image Upload System from Device Storage */}
                  <div className="bg-[#0a0f16] p-4 rounded-2xl border-2 border-dashed border-amber-500/60 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-extrabold text-amber-300 flex items-center gap-1.5 uppercase">
                        <Upload className="w-4 h-4 text-amber-400" />
                        Kura Cover Image Kuri Device Storage (Gallery / Files): *
                      </label>
                      <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                        Device Storage Ready 📱💻
                      </span>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row items-center gap-3">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleHeroImageFileChange}
                        className="hidden"
                        id="hero-banner-image-input"
                      />
                      <label
                        htmlFor="hero-banner-image-input"
                        className="cursor-pointer w-full sm:w-auto px-5 py-3 bg-gradient-to-r from-amber-500 to-orange-500 hover:brightness-110 text-black rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all shadow-md shadow-orange-500/30"
                      >
                        <ImageIcon className="w-4 h-4 stroke-[2.5]" />
                        <span>Kura Ifoto kuri Storage (Browse Files)</span>
                      </label>

                      <input
                        type="url"
                        placeholder="Cyangwa Paste Image URL hano..."
                        value={heroImageUrl}
                        onChange={(e) => {
                          setHeroImageUrl(e.target.value);
                          setHeroImagePreview(e.target.value);
                        }}
                        className="flex-1 w-full bg-[#111823] border border-cyan-900/60 rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    {(heroImagePreview || heroImageUrl) && (
                      <div className="pt-2 p-3 bg-[#111823] rounded-xl border border-amber-500/40 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={heroImagePreview || heroImageUrl}
                            alt="Hero Slide Preview"
                            className="w-24 h-14 object-cover rounded-lg border border-amber-400 shadow-md flex-shrink-0"
                          />
                          <div>
                            <span className="text-xs text-amber-300 font-black block">
                              ✓ Cover Image yabonetse kuri Storage!
                            </span>
                            <span className="text-[10px] text-gray-400">
                              Yiteguye kugaragara ku Welcome Page Hero Slide
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setHeroImagePreview('');
                            setHeroImageUrl('');
                          }}
                          className="px-2.5 py-1 text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/40 rounded-lg hover:bg-red-500 hover:text-white transition-colors"
                        >
                          Siba (Remove)
                        </button>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Video Direct Link (MP4 for Play Button):
                    </label>
                    <input
                      type="url"
                      placeholder="https://commondatastorage.googleapis.com/.../movie.mp4"
                      value={heroVideoUrl}
                      onChange={(e) => setHeroVideoUrl(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Ubusobanuro (Description / Synopsis):
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Andika amagambo make agize iyi hero banner..."
                      value={heroDescription}
                      onChange={(e) => setHeroDescription(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-4 h-4 fill-black" />
                    <span>{editingHeroId ? 'Save Hero Slide Changes' : 'Shyiraho Hero Banner Nshya ku Welcome Page'}</span>
                  </button>
                </form>

                {/* Existing Hero Slides List */}
                <div className="space-y-3">
                  <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">
                    Hero Banners Slide Ziri ku Welcome Page ({heroSlides.length})
                  </h4>

                  <div className="space-y-2.5 max-h-[35vh] overflow-y-auto pr-1">
                    {heroSlides.map((slide) => (
                      <div
                        key={slide.id}
                        className="flex items-center justify-between gap-3 bg-[#111823] p-3 rounded-xl border border-cyan-900/50 hover:border-cyan-500/40 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={slide.image}
                            alt={slide.title}
                            className="w-16 h-10 object-cover rounded-lg border border-cyan-500/40 flex-shrink-0"
                          />
                          <div className="min-w-0">
                            <h5 className="text-xs font-bold text-white truncate">{slide.title}</h5>
                            <p className="text-[10px] text-cyan-400 truncate">
                              {slide.translatorName} • {slide.category} ({slide.year})
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0">
                          <button
                            onClick={() => handleStartEditHeroSlide(slide)}
                            className="p-2 bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500 hover:text-black rounded-lg transition-colors text-xs font-bold flex items-center gap-1"
                          >
                            <Edit className="w-3.5 h-3.5" />
                            <span>Edit</span>
                          </button>

                          {onDeleteHeroSlide && (
                            <button
                              onClick={() => onDeleteHeroSlide(slide.id)}
                              className="p-2 bg-red-950/40 text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-colors"
                              title="Delete Hero Slide"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: UPLOAD FOLDER BUTTON FUNCTIONALITY (BATCH SERIES) */}
            {activeTab === 'folder_upload' && (
              <form onSubmit={handleUploadFolderSubmit} className="space-y-5 bg-[#111823] p-5 rounded-2xl border border-cyan-950/80">
                <div className="space-y-1">
                  <h4 className="text-base font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                    <Layers className="w-5 h-5 text-cyan-400" />
                    UPLOAD FOLDER SYSTEM (Batch Series Upload)
                  </h4>
                  <p className="text-xs text-cyan-400">
                    Kura folder yose y'amaserie kuri Storage ya Phone / PC yawe. System ihita isoma episodes zose ku muvuduko wo hejuru cyane!
                  </p>
                </div>

                {/* DEVICE FOLDER UPLOAD SELECTOR BUTTON */}
                <div className="bg-[#0a0f16] p-5 rounded-2xl border border-dashed border-cyan-500/50 text-center space-y-3">
                  <Zap className="w-8 h-8 text-cyan-400 mx-auto animate-pulse" />
                  
                  <div>
                    <h5 className="text-xs font-extrabold text-white uppercase tracking-wide">
                      Select Folder from Local Storage (Phone / PC)
                    </h5>
                    <p className="text-[11px] text-gray-400 mt-0.5">
                      Kanda hano uhitemo folder ifite video files (MP4, MKV)
                    </p>
                  </div>

                  <input
                    type="file"
                    /* @ts-ignore */
                    webkitdirectory=""
                    directory=""
                    multiple
                    onChange={handleSelectLocalDeviceFolder}
                    className="hidden"
                    id="device-folder-input"
                  />

                  <label
                    htmlFor="device-folder-input"
                    className="cursor-pointer inline-flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-cyan-400 to-sky-400 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-cyan-500/20 hover:scale-[1.02] transition-all"
                  >
                    <FolderUp className="w-4 h-4 stroke-[3]" />
                    <span>Hitamo Folder kuri Device Storage</span>
                  </label>

                  {isParsingFolder && (
                    <div className="space-y-1.5 pt-2 max-w-xs mx-auto">
                      <div className="flex items-center justify-between text-[10px] font-bold text-cyan-400">
                        <span>⚡ Ultra-Fast Parallel File Scanner</span>
                        <span>{parseProgress}%</span>
                      </div>
                      <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-cyan-400 h-full transition-all duration-300" style={{ width: `${parseProgress}%` }} />
                      </div>
                    </div>
                  )}

                  {parsedFolderFiles.length > 0 && (
                    <div className="p-3 bg-cyan-950/60 border border-cyan-500/40 rounded-xl text-left space-y-2">
                      <div className="flex items-center justify-between text-xs font-extrabold text-cyan-300">
                        <span>✓ Folder Files Detected: {parsedFolderFiles.length} Episodes</span>
                        <span className="bg-cyan-500/20 px-2 py-0.5 rounded text-[10px]">{totalFolderMB} Total Size</span>
                      </div>

                      <div className="max-h-28 overflow-y-auto space-y-1 text-[11px] text-gray-300 font-mono pr-1">
                        {parsedFolderFiles.slice(0, 10).map((f, i) => (
                          <div key={i} className="flex items-center justify-between bg-[#111823] px-2 py-1 rounded border border-gray-800">
                            <span className="truncate max-w-[200px] sm:max-w-[300px]">Ep {f.epNum}: {f.name}</span>
                            <span className="text-cyan-400 text-[10px]">{f.sizeFormatted}</span>
                          </div>
                        ))}
                        {parsedFolderFiles.length > 10 && (
                          <div className="text-[10px] text-gray-500 text-center font-bold pt-1">
                            + {parsedFolderFiles.length - 10} episodes additional detected...
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Izina rya Folder y'Amaserie (Folder Name): *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="E.g. CITY HUNT (Korea Series)"
                      value={folderName}
                      onChange={(e) => setFolderName(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Umusobanuzi (Translator):
                    </label>
                    <select
                      value={folderTranslator}
                      onChange={(e) => setFolderTranslator(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-cyan-400 font-extrabold focus:outline-none focus:border-cyan-400"
                    >
                      {translators.map((t) => (
                        <option key={t.id} value={t.name}>
                          {t.name} ({t.alias})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Category Section:
                    </label>
                    <select
                      value={folderCategory}
                      onChange={(e) => setFolderCategory(e.target.value as MovieCategory)}
                      className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white font-bold focus:outline-none focus:border-cyan-400"
                    >
                      <option value="Series">Series</option>
                      <option value="New Movies">New Movies</option>
                      <option value="Agasobanuye">Agasobanuye</option>
                      <option value="Action">Action</option>
                      <option value="Drama">Drama</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Umubare w'Episodes (Episode Count):
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      value={folderEpisodeCount}
                      onChange={(e) => setFolderEpisodeCount(Number(e.target.value))}
                      className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400 font-bold"
                    />
                  </div>
                </div>

                {/* Folder Poster Image upload */}
                <div className="bg-[#0a0f16] p-4 rounded-xl border border-dashed border-cyan-500/40 text-center space-y-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFolderPosterFileChange}
                    className="hidden"
                    id="folder-poster-input"
                  />
                  <label
                    htmlFor="folder-poster-input"
                    className="cursor-pointer flex flex-col items-center justify-center gap-1 text-cyan-400 hover:text-cyan-300"
                  >
                    <ImageIcon className="w-7 h-7 mx-auto" />
                    <span className="text-xs font-bold">Kura Photo ya Folder Cover kuri Storage (Gallery)</span>
                  </label>

                  <input
                    type="url"
                    placeholder="Cyangwa paste image URL ya Folder..."
                    value={folderPosterUrl}
                    onChange={(e) => setFolderPosterUrl(e.target.value)}
                    className="w-full bg-[#111823] border border-cyan-900/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400 mt-2"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1">
                    Ubusobanuro bwa Folder (Folder Description):
                  </label>
                  <textarea
                    rows={2}
                    placeholder="E.g. Korea Series ya City Hunt ifite episodes 20 isobanuwe na VJ Kabosio..."
                    value={folderDescription}
                    onChange={(e) => setFolderDescription(e.target.value)}
                    className="w-full bg-[#0a0f16] border border-cyan-900/60 rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black font-extrabold text-sm rounded-xl shadow-xl shadow-cyan-500/20 flex items-center justify-center gap-2"
                >
                  <FolderUp className="w-5 h-5 stroke-[2.5]" />
                  <span>Kora Upload ya Folder ku Welcome Page</span>
                </button>
              </form>
            )}


            {/* TAB 3: 24H STATUS VIDEOS UPLOAD SYSTEM */}
            {activeTab === 'status' && (
              <div className="space-y-5">
                <div className="bg-emerald-950/40 border border-emerald-500/40 p-4 rounded-2xl space-y-1">
                  <h4 className="text-sm font-extrabold text-emerald-300 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-emerald-400" />
                    STATUS VIDEOS SYSTEM (WhatsApp-like Status)
                  </h4>
                  <p className="text-xs text-gray-300">
                    Status izamara **amasaha 24** ikahita iva kuri web. Bara rya **green ring** rizengurutse ku foto ya Translator rijyaho nyuma yo gushyiraho status video! (Max duration: 1 Minute).
                  </p>
                </div>

                <form onSubmit={handleSubmitStatus} className="space-y-4 bg-[#111823] p-5 rounded-2xl border border-emerald-950/80">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Hitamo Umusobanuzi (Translator):
                    </label>
                    <select
                      value={statusTranslatorId}
                      onChange={(e) => setStatusTranslatorId(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-emerald-400 font-extrabold focus:outline-none focus:border-emerald-400"
                    >
                      {translators.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.alias})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-3">
                    <label className="block text-xs font-bold text-gray-300">
                      Uburyo bwo kuzana Status Video (Max 1 min):
                    </label>

                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setStatusVideoMode('file')}
                        className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 ${
                          statusVideoMode === 'file'
                            ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                            : 'bg-gray-900 border-gray-800 text-gray-400'
                        }`}
                      >
                        <Upload className="w-4 h-4" /> Kura Video kuri Storage (MP4)
                      </button>

                      <button
                        type="button"
                        onClick={() => setStatusVideoMode('link')}
                        className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 ${
                          statusVideoMode === 'link'
                            ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                            : 'bg-gray-900 border-gray-800 text-gray-400'
                        }`}
                      >
                        <LinkIcon className="w-4 h-4" /> Direct Video Link
                      </button>
                    </div>

                    {statusVideoMode === 'file' && (
                      <div className="p-4 bg-[#0a0f16] rounded-xl border border-dashed border-emerald-500/50 text-center">
                        <input
                          type="file"
                          accept="video/*"
                          onChange={handleStatusVideoChange}
                          className="hidden"
                          id="status-video-input"
                        />
                        <label
                          htmlFor="status-video-input"
                          className="cursor-pointer flex flex-col items-center justify-center gap-1 text-emerald-400 hover:text-emerald-300"
                        >
                          <Video className="w-7 h-7 mx-auto" />
                          <span className="text-xs font-bold">Kanda hano ukure Status Video kuri Phone/PC</span>
                        </label>

                        {statusVideoFile && (
                          <div className="pt-2 text-xs text-emerald-300 font-mono font-bold">
                            ✓ Status Video Selected: {statusVideoFile.name}
                          </div>
                        )}
                      </div>
                    )}

                    {statusVideoMode === 'link' && (
                      <input
                        type="url"
                        placeholder="https://example.com/status.mp4"
                        value={statusVideoUrl}
                        onChange={(e) => setStatusVideoUrl(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                      />
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Icyo uvuga kuri status (Caption Text):
                    </label>
                    <input
                      type="text"
                      placeholder="E.g. City Hunt iri gushya kuri AfriMovies! Muryoherwe"
                      value={statusCaption}
                      onChange={(e) => setStatusCaption(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-emerald-400 to-emerald-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2"
                  >
                    <Video className="w-4 h-4 fill-black" />
                    <span>Shyiraho Status Video (24 Hours Active)</span>
                  </button>

                </form>

                <div className="space-y-3">
                  <h4 className="text-xs font-extrabold text-gray-300 uppercase tracking-wider">
                    Status Video Ziri Active ({statuses.length})
                  </h4>

                  <div className="space-y-2">
                    {statuses.map((st) => (
                      <div
                        key={st.id}
                        className="flex items-center justify-between p-3 bg-[#111823] rounded-xl border border-emerald-950/60"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={st.translatorAvatar}
                            alt={st.translatorName}
                            className="w-10 h-10 rounded-full object-cover ring-2 ring-emerald-400"
                          />
                          <div>
                            <h5 className="text-xs font-bold text-white">{st.translatorName}</h5>
                            <p className="text-[10px] text-emerald-400">{st.caption || 'No caption'}</p>
                          </div>
                        </div>

                        <button
                          onClick={() => onDeleteStatus(st.id)}
                          className="p-2 bg-red-950/50 text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-colors"
                          title="Delete Status"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* TAB 4: TRANSLATORS PHOTOS UPLOADING SYSTEM */}
            {activeTab === 'translators' && (
              <div className="space-y-5">
                <div className="bg-emerald-950/40 border border-emerald-500/40 p-4 rounded-2xl space-y-1">
                  <h4 className="text-sm font-extrabold text-emerald-300 flex items-center gap-2">
                    <ImageIcon className="w-4 h-4 text-emerald-400" />
                    TRANSLATORS PHOTO UPLOADING SYSTEM
                  </h4>
                  <p className="text-xs text-gray-300">
                    Hindura ifoto ya Translator kureba kuri OUR TRANSLATORS bar. Kura amafoto kuri **storage ya device** yawe!
                  </p>
                </div>

                <form onSubmit={handleUpdateTranslatorProfile} className="space-y-4 bg-[#111823] p-5 rounded-2xl border border-emerald-950/80">
                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Hitamo Umusobanuzi wo gushyiraho ifoto nshya:
                    </label>
                    <select
                      value={editingTranslatorId}
                      onChange={(e) => setEditingTranslatorId(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-3.5 py-2.5 text-xs text-emerald-400 font-extrabold focus:outline-none focus:border-emerald-400"
                    >
                      {translators.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.alias})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-3">
                    <label className="block text-xs font-bold text-gray-300">
                      Ifoto Nshya (Upload Photo from Storage):
                    </label>

                    <div className="p-4 bg-[#0a0f16] rounded-xl border border-dashed border-emerald-500/50 text-center">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleTranslatorAvatarFileChange}
                        className="hidden"
                        id="translator-avatar-input"
                      />
                      <label
                        htmlFor="translator-avatar-input"
                        className="cursor-pointer flex flex-col items-center justify-center gap-1 text-emerald-400 hover:text-emerald-300"
                      >
                        <ImageIcon className="w-8 h-8 mx-auto" />
                        <span className="text-xs font-bold">Kanda hano ukure Ifoto nshya kuri Storage ya Phone/PC</span>
                      </label>
                    </div>

                    <div className="text-[10px] text-gray-400">Cyangwa andika Avatar Photo URL:</div>
                    <input
                      type="url"
                      placeholder="https://images.unsplash.com/..."
                      value={translatorAvatarUrl}
                      onChange={(e) => setTranslatorAvatarUrl(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                    />

                    {(translatorAvatarFilePreview || translatorAvatarUrl) && (
                      <div className="flex items-center gap-3 pt-2">
                        <img
                          src={translatorAvatarFilePreview || translatorAvatarUrl}
                          alt="Avatar Preview"
                          className="w-14 h-14 rounded-full object-cover ring-2 ring-emerald-400"
                        />
                        <span className="text-xs text-emerald-300 font-bold">
                          ✓ Photo Preview Ready
                        </span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Ubwoko asobanura (Specialty):
                    </label>
                    <input
                      type="text"
                      placeholder="E.g. Action, Sci-Fi & Blockbusters"
                      value={translatorSpecialty}
                      onChange={(e) => setTranslatorSpecialty(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-400"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-emerald-400 to-emerald-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>Vugurura Ifoto ya Translator (Update Photo)</span>
                  </button>

                </form>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {translators.map((t) => (
                    <div key={t.id} className="p-3 bg-[#111823] rounded-xl border border-emerald-950/60 flex items-center gap-2.5">
                      <img src={t.avatar} alt={t.name} className="w-10 h-10 rounded-full object-cover ring-2 ring-emerald-500" />
                      <div className="min-w-0">
                        <h5 className="text-xs font-bold text-white truncate">{t.name}</h5>
                        <p className="text-[10px] text-emerald-400 truncate">{t.specialty}</p>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            )}

            {/* TAB 5: MANAGE & EDIT WELCOME PAGE CONTENT */}
            {activeTab === 'manage' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-extrabold text-white">
                    Full Control: Edit cyangwa Siba content iri ku Welcome page ({movies.length})
                  </h4>
                </div>

                <div className="space-y-2.5 max-h-[50vh] overflow-y-auto pr-1">
                  {movies.map((m) => (
                    <div
                      key={m.id}
                      className="flex items-center justify-between gap-3 bg-[#111823] p-3 rounded-2xl border border-emerald-950/60 hover:border-emerald-500/40 transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img src={m.poster} alt={m.title} className="w-10 h-14 object-cover rounded-lg flex-shrink-0" />
                        <div className="min-w-0">
                          <h5 className="text-xs font-bold text-white truncate">{m.title}</h5>
                          <div className="flex items-center gap-2 text-[10px] text-gray-400 mt-0.5">
                            <span className="text-emerald-400 font-bold">{m.translatorName}</span>
                            <span>•</span>
                            <span>{m.category}</span>
                            <span>•</span>
                            <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-extrabold">
                              {m.status || 'NEW'}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-shrink-0">
                        {/* EDIT BUTTON (FULL CONTROL) */}
                        <button
                          onClick={() => handleStartEditMovie(m)}
                          className="px-2.5 py-1.5 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-black rounded-xl text-xs font-bold border border-emerald-500/40 flex items-center gap-1 transition-all"
                          title="Edit movie content"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>

                        <select
                          value={m.status || 'NEW'}
                          onChange={(e) => onUpdateMovieStatus(m.id, e.target.value as MovieStatus)}
                          className="bg-[#0a0f16] text-emerald-400 border border-emerald-900/60 rounded-lg px-2 py-1 text-[10px] font-bold"
                        >
                          <option value="NEW">NEW</option>
                          <option value="LIVE">LIVE</option>
                          <option value="TRENDING">TRENDING</option>
                          <option value="EXCLUSIVE">EXCLUSIVE</option>
                          <option value="UPCOMING">UPCOMING</option>
                        </select>

                        <button
                          onClick={() => onDeleteMovie(m.id)}
                          className="p-2 rounded-xl bg-red-950/40 text-red-400 hover:bg-red-500 hover:text-white transition-colors"
                          title="Delete Video"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* DOWNLOAD CONTROLLER TAB (ON / OFF SWITCH FOR DOWNLOAD BUTTONS) */}
            {activeTab === 'download_control' && (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-cyan-950/80 via-blue-950/80 to-cyan-950/80 p-6 rounded-3xl border border-cyan-500/40 shadow-xl space-y-4">
                  <div className="flex items-center justify-between gap-4 flex-wrap border-b border-cyan-950/80 pb-4">
                    <div className="space-y-1">
                      <h4 className="text-base font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                        <Download className="w-5 h-5 text-cyan-400" />
                        DOWNLOAD CONTROLLER (DOWNLOAD BUTTONS ON / OFF)
                      </h4>
                      <p className="text-xs text-gray-300">
                        Aha niho ucana **(ON)** cyangwa ukazimya **(OFF)** ama-button yose ya Download ari ku ma-post yose, muri video player no muri amaserie folder views.
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider border shadow-md ${
                        downloadsEnabled 
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow-emerald-950' 
                          : 'bg-red-500/20 text-red-400 border-red-500/40 shadow-red-950'
                      }`}>
                        STATUS: {downloadsEnabled ? 'ON (ACTIVE & VISIBLE)' : 'OFF (HIDDEN ACROSS SITE)'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (onToggleDownloads) onToggleDownloads(true);
                        setSuccessMsg("✓ Ama-Button yose ya Download YACANWE (ON)! Yagaruwe ku ma-post yose.");
                        setTimeout(() => setSuccessMsg(''), 3500);
                      }}
                      className={`py-5 px-6 rounded-2xl font-black text-xs flex items-center justify-center gap-3 transition-all border shadow-lg ${
                        downloadsEnabled
                          ? 'bg-gradient-to-r from-emerald-400 to-teal-400 text-black border-emerald-300 ring-2 ring-emerald-400/50 scale-[1.02]'
                          : 'bg-[#0d131d] text-gray-400 border-gray-800 hover:text-white hover:bg-gray-800'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                      </div>
                      <div className="text-left">
                        <div className="text-sm font-extrabold">DOWNLOAD ON</div>
                        <div className="text-[10px] opacity-80 font-medium">Erekana download buttons ku ma-post yose</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (onToggleDownloads) onToggleDownloads(false);
                        setSuccessMsg("✓ Ama-Button yose ya Download YAZIMIJWE (OFF)! Yavuye ku ma-post yose.");
                        setTimeout(() => setSuccessMsg(''), 3500);
                      }}
                      className={`py-5 px-6 rounded-2xl font-black text-xs flex items-center justify-center gap-3 transition-all border shadow-lg ${
                        !downloadsEnabled
                          ? 'bg-gradient-to-r from-red-500 to-rose-600 text-white border-red-400 ring-2 ring-red-400/50 scale-[1.02]'
                          : 'bg-[#0d131d] text-gray-400 border-gray-800 hover:text-white hover:bg-gray-800'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-black/20 flex items-center justify-center flex-shrink-0">
                        <X className="w-5 h-5 stroke-[2.5]" />
                      </div>
                      <div className="text-left">
                        <div className="text-sm font-extrabold">DOWNLOAD OFF</div>
                        <div className="text-[10px] opacity-80 font-medium">Hisha download buttons ku ma-post yose</div>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 6: SETTINGS (WHATSAPP LINK & REQUEST PHONE & DOWNLOAD CONTROLLER) */}
            {activeTab === 'settings' && (
              <div className="space-y-6">
                <form onSubmit={handleSaveWhatsappLink} className="space-y-4 bg-[#111823] p-5 rounded-2xl border border-emerald-950/80">
                  <div className="space-y-1">
                    <h4 className="text-base font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                      <MessageCircle className="w-5 h-5 text-emerald-400" />
                      WHATSAPP GROUP LINK CONFIGURATION
                    </h4>
                    <p className="text-xs text-gray-300">
                      Shyiraho link ya WhatsApp Group cyawe. Iyo abasomyi bakande kuri **JOIN US** izajya ikoresha iyi link bahite binjira muri group yawe!
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      WhatsApp Group Link URL:
                    </label>
                    <input
                      type="url"
                      required
                      placeholder="https://chat.whatsapp.com/your-group-invite-code"
                      value={customWhatsappLink}
                      onChange={(e) => setCustomWhatsappLink(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-4 py-3 text-xs text-emerald-400 font-mono font-bold focus:outline-none focus:border-emerald-400"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-gradient-to-r from-emerald-400 to-emerald-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Bika Link ya WhatsApp (Save WhatsApp Group Link)</span>
                  </button>
                </form>

                <div className="space-y-4 bg-[#111823] p-5 rounded-2xl border border-emerald-950/80">
                  <div className="space-y-1">
                    <h4 className="text-base font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                      <MessageCircle className="w-5 h-5 text-emerald-400" />
                      NOMERO YA WHATSAPP ZIZAJYA ZOHEREZWOHO UBUSABE BWA FILIME
                    </h4>
                    <p className="text-xs text-gray-300">
                      Muri form ya **"Saba Filime cg Serie"**, iyo umufana akanze **Ohereza Ubusabe**, azajya yohereza ubusabe bwe kuri iyi nomero ya WhatsApp!
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-300 mb-1">
                      Nomero ya WhatsApp (E.g. 250780000000 / 0780000000):
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="250780000000"
                      value={customRequestNumber}
                      onChange={(e) => setCustomRequestNumber(e.target.value)}
                      className="w-full bg-[#0a0f16] border border-emerald-900/60 rounded-xl px-4 py-3 text-xs text-emerald-400 font-mono font-bold focus:outline-none focus:border-emerald-400"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (onUpdateRequestWhatsappNumber) {
                        onUpdateRequestWhatsappNumber(customRequestNumber);
                      }
                      setSuccessMsg("✓ Nomero ya WhatsApp y'ubusabe yabitswe neza!");
                      setTimeout(() => setSuccessMsg(''), 3500);
                    }}
                    className="w-full py-3.5 bg-gradient-to-r from-emerald-400 to-emerald-500 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    <span>Bika Nomero ya WhatsApp y'Ubusabe</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 9: ADMIN ACCOUNTS CONTROLLER (MAIN ADMIN & SUB ADMIN ACCESS) */}
            {activeTab === 'accounts' && (
              <div className="space-y-6">
                
                {/* CURRENT LOGGED IN ADMIN PROFILE CARD */}
                <div className="p-5 bg-gradient-to-r from-[#0f172a] via-[#111827] to-[#1e1b4b] rounded-2xl border-2 border-emerald-500/50 shadow-xl space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      {/* Avatar Image with Hover Camera Upload Badge */}
                      <div className="relative group w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 border-2 border-emerald-400/60 flex items-center justify-center text-xl font-bold overflow-hidden shadow-lg flex-shrink-0">
                        {currentUser?.avatar ? (
                          <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
                        ) : (
                          <User className="w-8 h-8" />
                        )}
                        <label
                          htmlFor="admin-profile-avatar-upload"
                          className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer p-1 text-center"
                          title="Hindura / Upload Profile Picture"
                        >
                          <Camera className="w-5 h-5 text-emerald-400" />
                          <span className="text-[8px] font-extrabold uppercase tracking-tighter leading-tight mt-0.5 text-emerald-300">Edit Foto</span>
                        </label>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-base font-extrabold text-white">{currentUser?.name || 'Admin'} Profile</h4>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                            currentUser?.role === 'MAIN_ADMIN'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                              : 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                          }`}>
                            {currentUser?.role === 'MAIN_ADMIN' ? '👑 Main Admin (Owner)' : 'Sub Admin'}
                          </span>
                        </div>
                        <p className="text-xs text-gray-300 font-mono mt-0.5">{currentUser?.email}</p>
                        
                        {/* Quick Action Upload Buttons */}
                        <div className="flex items-center gap-2 mt-2">
                          <input
                            id="admin-profile-avatar-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleAvatarFileSelect}
                            className="hidden"
                          />
                          <label
                            htmlFor="admin-profile-avatar-upload"
                            className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors shadow"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Upload Foto</span>
                          </label>

                          {currentUser?.avatar && (
                            <button
                              type="button"
                              onClick={() => handleSaveAvatar('')}
                              className="px-2 py-1 bg-red-900/40 hover:bg-red-800 text-red-300 rounded-lg text-[11px] font-bold flex items-center gap-1 border border-red-500/30 cursor-pointer transition-colors"
                              title="Gukura ifoto kuri Profile"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Gukura foto</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleLogout}
                      className="px-4 py-2.5 bg-red-600 hover:bg-red-500 active:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-red-950/60 transition-all flex items-center gap-2 cursor-pointer border border-red-400/40"
                      title="Sohoka muri Admin (Log Out)"
                    >
                      <LogOut className="w-4 h-4 stroke-[2.5]" />
                      <span className="uppercase tracking-wider">LOG OUT (SOHOKA)</span>
                    </button>
                  </div>

                  {/* Additional Option: Paste Image URL */}
                  <div className="pt-3 border-t border-gray-800 space-y-3">
                    <div className="flex flex-wrap items-end gap-2">
                      <div className="flex-1 min-w-[200px]">
                        <label className="block text-[11px] font-extrabold text-gray-300 mb-1 flex items-center gap-1">
                          <ImageIcon className="w-3.5 h-3.5 text-emerald-400" /> Koresha Image URL (Link y'ifoto ya Profile):
                        </label>
                        <input
                          type="url"
                          placeholder="https://example.com/my-photo.jpg"
                          value={profileAvatarInput}
                          onChange={(e) => setProfileAvatarInput(e.target.value)}
                          className="w-full bg-[#0a0f16] border border-emerald-500/40 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (profileAvatarInput.trim()) {
                            handleSaveAvatar(profileAvatarInput.trim());
                            setProfileAvatarInput('');
                          }
                        }}
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Save className="w-3.5 h-3.5" /> Bika URL
                      </button>
                    </div>

                    {profileAvatarMsg && (
                      <p className="text-xs font-bold text-emerald-400 bg-emerald-950/60 p-2 rounded-lg border border-emerald-500/40">
                        {profileAvatarMsg}
                      </p>
                    )}

                    {/* Quick Change Password Form for Current Profile */}
                    <form onSubmit={handleUpdateProfilePassword} className="pt-2 flex flex-wrap items-end gap-3">
                      <div className="flex-1 min-w-[200px]">
                        <label className="block text-[11px] font-extrabold text-gray-300 mb-1 flex items-center gap-1">
                          <Key className="w-3.5 h-3.5 text-emerald-400" /> Hindura Password ya Profile yawe:
                        </label>
                        <input
                          type="text"
                          placeholder="Shyiramo password nshya..."
                          value={profilePass}
                          onChange={(e) => setProfilePass(e.target.value)}
                          className="w-full bg-[#0a0f16] border border-emerald-500/40 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
                        />
                      </div>
                      <button
                        type="submit"
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Save className="w-3.5 h-3.5" /> Bika Password Nshya
                      </button>
                    </form>
                    {profilePassMsg && (
                      <p className="text-xs font-bold text-emerald-400 bg-emerald-950/60 p-2 rounded-lg border border-emerald-500/40">
                        {profilePassMsg}
                      </p>
                    )}
                  </div>
                </div>

                <div className="p-4 bg-[#111823] rounded-2xl border border-amber-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-amber-400" />
                      <h3 className="text-sm font-black text-white uppercase tracking-wider">
                        ADMIN ACCOUNTS CONTROLLER & SECURITY
                      </h3>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-500/20 text-amber-400 border border-amber-500/40">
                      {currentUser?.role === 'MAIN_ADMIN' ? '👑 Main Admin Control' : 'Sub-Admin Access'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed">
                    Nka Main Admin, ufite ubushobozi bwo kureba list y'ama accounts ya Admin, gublock no gudeblock account ya 2 (<strong className="text-amber-400">AFRIMovies</strong>), no kuyisiba (delete) igihe icyo ari cyo cyose.
                  </p>
                </div>

                {/* Registered Admin Accounts List */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center justify-between">
                    <span>LIST Y'AMA ACCOUNTS YA ADMIN ({adminAccounts.length}):</span>
                    <span className="text-[10px] text-emerald-400 font-extrabold">✓ Logged in as: {currentUser?.name || 'Main Admin'}</span>
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {adminAccounts.map((acc) => {
                      const isMain = acc.role === 'MAIN_ADMIN';
                      return (
                        <div
                          key={acc.id}
                          className={`p-4 rounded-2xl border flex flex-col justify-between space-y-4 transition-all ${
                            isMain
                              ? 'bg-[#0f172a] border-amber-500/60 shadow-lg shadow-amber-950/30'
                              : acc.isBlocked
                              ? 'bg-red-950/20 border-red-500/50'
                              : 'bg-[#111823] border-cyan-500/40'
                          }`}
                        >
                          <div className="space-y-2.5">
                            <div className="flex items-center justify-between">
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                                isMain
                                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                                  : acc.isBlocked
                                  ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              }`}>
                                {isMain ? '👑 MAIN ADMIN (OWNER)' : acc.isBlocked ? '⛔ BLOCKED (LOGIN DENIED)' : '✓ ACTIVE SUB-ADMIN'}
                              </span>

                              <span className="text-[10px] font-mono text-gray-400">
                                {isMain ? 'Main Account' : 'Secondary Account'}
                              </span>
                            </div>

                            <div>
                              <h5 className="text-base font-extrabold text-white flex items-center gap-1.5">
                                {acc.name}
                              </h5>
                              <p className="text-xs font-mono text-amber-300 font-semibold flex items-center gap-1.5 mt-1">
                                <Mail className="w-3.5 h-3.5 text-amber-400" /> <span className="select-all">{acc.email}</span>
                              </p>
                              <p className="text-xs font-mono text-gray-300 flex items-center gap-1.5 mt-1">
                                <Key className="w-3.5 h-3.5 text-gray-400" /> Password: <span className="text-emerald-400 font-bold select-all">{acc.password}</span>
                              </p>
                            </div>
                          </div>

                          {/* Controls available for non-Main accounts (e.g. AFRIMovies account) */}
                          {!isMain && (
                            <div className="pt-3 border-t border-gray-800 flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => handleToggleBlockAccount(acc.id)}
                                className={`flex-1 py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md ${
                                  acc.isBlocked
                                    ? 'bg-emerald-400 hover:bg-emerald-300 text-black'
                                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/50 hover:bg-amber-500 hover:text-black'
                                }`}
                              >
                                {acc.isBlocked ? (
                                  <>
                                    <UserCheck className="w-4 h-4 stroke-[2.5]" /> Deblock Account (Restore Access)
                                  </>
                                ) : (
                                  <>
                                    <UserX className="w-4 h-4 stroke-[2.5]" /> Block Account (Deny Access)
                                  </>
                                )}
                              </button>

                              <button
                                type="button"
                                onClick={() => handleDeleteAccount(acc.id)}
                                className="py-2 px-3 bg-red-500/20 text-red-400 border border-red-500/50 hover:bg-red-500 hover:text-white rounded-xl text-xs font-black flex items-center gap-1 transition-all"
                                title="Siba Iyi Account"
                              >
                                <Trash2 className="w-4 h-4" /> Delete Account
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Form to Add New Sub Admin Account */}
                <div className="bg-[#111823] p-5 rounded-2xl border border-amber-500/30 space-y-4">
                  <h4 className="text-xs font-extrabold text-amber-300 uppercase tracking-wider flex items-center gap-2">
                    <Plus className="w-4 h-4 text-amber-400" /> Rema cyangwa ongera indi Sub-Admin Account:
                  </h4>

                  <form onSubmit={handleCreateSubAccount} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 mb-1">Izina ry'Account:</label>
                      <input
                        type="text"
                        placeholder="E.g. AFRIMovies"
                        value={newSubName}
                        onChange={(e) => setNewSubName(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-gray-800 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 mb-1">Email Address: *</label>
                      <input
                        type="email"
                        required
                        placeholder="E.g. email.afrimovies240@gmail.com"
                        value={newSubEmail}
                        onChange={(e) => setNewSubEmail(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-gray-800 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 mb-1">Password: *</label>
                      <input
                        type="text"
                        required
                        placeholder="E.g. King@240"
                        value={newSubPassword}
                        onChange={(e) => setNewSubPassword(e.target.value)}
                        className="w-full bg-[#0a0f16] border border-gray-800 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div className="sm:col-span-3 flex justify-end pt-1">
                      <button
                        type="submit"
                        className="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-orange-400 hover:brightness-110 text-black font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4 stroke-[2.5]" /> Siga Account Nshya (Create Account)
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

          </div>
        )}

      </div>

      {/* YOUR POST WAS POSTED SUCCESSFULLY PROMPT MODAL */}
      {showPostSuccessModal && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-[#0c121a] border border-emerald-500/80 rounded-3xl p-6 max-w-md w-full shadow-2xl shadow-emerald-950 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 p-1 mx-auto flex items-center justify-center border border-emerald-500/50">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-black text-white">Your post was posted successfully!</h3>
              <p className="text-xs font-bold text-emerald-400">
                ✓ Post yashyizweho neza ku Welcome Page ya AfriMovies!
              </p>
            </div>

            <p className="text-xs text-gray-300">
              Wifuza gukora indi post nshya cyangwa kureba muri Welcome page?
            </p>

            <div className="flex flex-col sm:flex-row gap-2 pt-2">
              <button
                onClick={() => {
                  setShowPostSuccessModal(false);
                  setActiveTab('upload');
                  handleCancelEdit();
                }}
                className="flex-1 py-3 bg-emerald-400 hover:bg-emerald-300 text-black font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4 stroke-[3]" /> Kora Indi Post (Upload Another)
              </button>

              <button
                onClick={() => {
                  setShowPostSuccessModal(false);
                  onClose();
                }}
                className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 text-gray-200 border border-gray-700 font-extrabold text-xs rounded-xl transition-all"
              >
                Sura Welcome Page
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
