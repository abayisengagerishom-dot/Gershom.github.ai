export interface Translator {
  id: string;
  name: string;
  alias?: string;
  avatar: string;
  movieCount: number;
  isLive?: boolean;
  specialty: string;
  bio: string;
  hasActiveStatus?: boolean;
}

export interface TranslatorStatus {
  id: string;
  translatorId: string;
  translatorName: string;
  translatorAvatar: string;
  videoUrl: string;
  caption?: string;
  createdAt: number; // ms timestamp
  expiresAt: number; // createdAt + 24*3600*1000
  durationSeconds?: number; // max 60s
}

export interface Episode {
  id: string;
  number: number;
  title: string;
  duration: string;
  thumbnail: string;
  videoUrl: string;
}

export interface Comment {
  id: string;
  user: string;
  avatar: string;
  text: string;
  time: string;
  likes: number;
}

export type MovieCategory = 'New Movies' | 'Agasobanuye' | 'Series' | 'Action' | 'Drama' | 'Sci-Fi' | 'Comedy' | 'Thriller' | 'Romance';

export type MovieStatus = 'NEW' | 'LIVE' | 'TRENDING' | 'EXCLUSIVE' | 'UPCOMING';

export interface Movie {
  id: string;
  title: string;
  originalTitle?: string;
  year: number;
  translatorId: string;
  translatorName: string;
  category: MovieCategory;
  type: 'Movie' | 'Series';
  poster: string;
  banner?: string;
  rating: number;
  views: string;
  duration?: string;
  seasons?: number;
  episodesCount?: number;
  description: string;
  isLatest?: boolean;
  isFeatured?: boolean;
  status?: MovieStatus;
  videoUrl: string;
  episodes?: Episode[];
  comments: Comment[];
  quality: 'HD 1080p' | 'HD 720p' | '4K Ultra';
}

export type NavTab = 'home' | 'browse' | 'series' | 'dub' | 'nation' | 'search' | 'all_series';

export interface HeroSlide {
  id: string;
  title: string;
  originalTitle?: string;
  translatorName: string;
  description: string;
  image: string; // Banner or poster image URL / base64 uploaded from storage
  videoUrl: string;
  category: string;
  rating: number;
  year: number;
  type: 'Movie' | 'Series';
}
