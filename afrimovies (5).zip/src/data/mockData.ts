import { Translator, Movie, TranslatorStatus } from '../types';

export const INITIAL_STATUSES: TranslatorStatus[] = [
  {
    id: 'status-1',
    translatorId: 'rocky',
    translatorName: 'ROCKY KIMO',
    translatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    caption: 'Gladiator II Muryohewe! Filime nshya yasohotse uyu munsi.',
    createdAt: Date.now() - 2 * 60 * 60 * 1000, // 2 hours ago
    expiresAt: Date.now() + 22 * 60 * 60 * 1000, // expires in 22h
    durationSeconds: 45
  },
  {
    id: 'status-2',
    translatorId: 'kabosio',
    translatorName: 'VJ KABOSIO',
    translatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    caption: 'Series Nshya iri kuri CINEVA uyu munsi! Muryoherwe!',
    createdAt: Date.now() - 5 * 60 * 60 * 1000, // 5 hours ago
    expiresAt: Date.now() + 19 * 60 * 60 * 1000, // expires in 19h
    durationSeconds: 30
  }
];

export const TRANSLATORS: Translator[] = [
  {
    id: 'bthegreat',
    name: 'B THE GREAT',
    alias: 'B The Great',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    movieCount: 16,
    isLive: true,
    specialty: 'Action, Blockbusters & Sci-Fi',
    bio: 'B The Great, umusobanuzi w\'ikirenga uzwiho ubuhanga mu gusobanura filime z\'intambara no kuziryoheza.'
  },
  {
    id: 'rocky',
    name: 'ROCKY KIMO',
    alias: 'Rocky Kimomo',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    movieCount: 12,
    isLive: true,
    specialty: 'Action, Sci-Fi & Blockbusters',
    bio: 'Umwe mu basobanuzi bakunzwe cyane mu Rwanda uzwiho amagambo atyaye n\'uburyo bwo kuryoshya film.'
  },
  {
    id: 'kabosio',
    name: 'VJ KABOSIO',
    alias: 'Kabosio',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    movieCount: 13,
    isLive: true,
    specialty: 'Drama, Series & Romance',
    bio: 'VJ Kabosio azwiho guhindura neza amaserie muremure n\'amatsiko menshi.'
  },
  {
    id: 'sankara',
    name: 'SANKARA',
    alias: 'VJ Sankara',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80',
    movieCount: 15,
    isLive: false,
    specialty: 'Horror, Thriller & Comedy',
    bio: 'Mwalimu Sankara, usobanura filime z\'ubwoba n\'ibitekerezo bishya.'
  },
  {
    id: 'hakim',
    name: 'HAKIM Prof',
    alias: 'Hakim Professor',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80',
    movieCount: 10,
    isLive: false,
    specialty: 'Martial Arts & Asian Cinema',
    bio: 'Professor Hakim, umuhanga mu gukurikirana no gusobanura filime z\'intambara n\'ingabo.'
  },
  {
    id: 'gaheza',
    name: 'GAHEZA',
    alias: 'VJ Gaheza',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
    movieCount: 8,
    isLive: true,
    specialty: 'Series & Nollywood/Hollywood',
    bio: 'Gaheza akaba umusobanuzi w\'umwihariko utuma urieka gukubita ijisho kure.'
  },
  {
    id: 'junior',
    name: 'VJ JUNIOR',
    alias: 'Junior Giti',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    movieCount: 18,
    isLive: true,
    specialty: 'Legendary Dubbing Master',
    bio: 'Mwalimu w\'agasobanuye mu Rwanda, umenyerewe mu buryo oburyoheye amatwi.'
  },
  {
    id: 'muhitinzi',
    name: 'MUHITINZI',
    alias: 'VJ Muhitinzi',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
    movieCount: 14,
    isLive: false,
    specialty: 'Crime & Action Series',
    bio: 'Umusobanuzi ugira ijwi riremereye n\'ijambo rihamye.'
  }
];

export const MOVIES: Movie[] = [
  {
    id: 'age-of-adaline',
    title: 'Age of Adaline',
    originalTitle: 'The Age of Adaline',
    year: 2024,
    translatorId: 'rocky',
    translatorName: 'ROCKY KIMO',
    category: 'Romance',
    type: 'Movie',
    poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&q=80',
    rating: 4.8,
    views: '142K',
    duration: '1h 52m',
    description: 'Umugore umaze imyaka 80 atagira icyo ahindukaho cyangwa ngo asaze nyuma y\'impanuka y\'agatangaza. Rocky Kimomo abisobanura mu buryo bw\'agatangaza!',
    isLatest: true,
    isFeatured: true,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    quality: 'HD 1080p',
    comments: [
      { id: '1', user: 'Eric_Kigali', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80', text: 'Rocky yariyemeje kuri iyi film! Iryo jwi ni hatari.', time: '2 hours ago', likes: 24 },
      { id: '2', user: 'Keza_M', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80', text: 'Film nziza cyane n\'agasobanuye kararyoshye.', time: '5 hours ago', likes: 18 }
    ]
  },
  {
    id: 'middle-school',
    title: 'Middle school',
    originalTitle: 'Middle School: The Worst Years of My Life',
    year: 2018,
    translatorId: 'sankara',
    translatorName: 'SANKARA',
    category: 'Comedy',
    type: 'Movie',
    poster: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?auto=format&fit=crop&w=1200&q=80',
    rating: 4.6,
    views: '98K',
    duration: '1h 32m',
    description: "Umunyeshuri unyuranya n'amagege y'ikigo gitegeka ibintu bikomeye. Sankara azana rwenya no gusetsa mu Kinyarwanda cy'umwimerere.",
    isLatest: true,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    quality: 'HD 720p',
    comments: [
      { id: '3', user: 'Rugamba_01', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=100&q=80', text: 'Sankara ni mwalimu wo kuryoshya comédie!', time: '1 day ago', likes: 31 }
    ]
  },
  {
    id: 'major',
    title: 'MAJOR',
    originalTitle: 'Major Action Force',
    year: 2024,
    translatorId: 'rocky',
    translatorName: 'ROCKY KIMO',
    category: 'Action',
    type: 'Movie',
    poster: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1200&q=80',
    rating: 4.9,
    views: '210K',
    duration: '2h 10m',
    description: 'Ingabo idasanzwe irwanira igihugu mu buryo bw\'ubutwari n\'ishema. Rocky Kimo ayisobanura yikora ku mutima.',
    isLatest: true,
    isFeatured: true,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    quality: '4K Ultra',
    comments: [
      { id: '4', user: 'Innocent_H', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?auto=format&fit=crop&w=100&q=80', text: 'Iyi movie ni umliro wose! Rocky aratwitegeka.', time: '3 hours ago', likes: 45 }
    ]
  },
  {
    id: 'bad-sister',
    title: 'Bad sister',
    originalTitle: 'The Bad Sister Mystery',
    year: 2024,
    translatorId: 'sankara',
    translatorName: 'SANKARA',
    category: 'Thriller',
    type: 'Movie',
    poster: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
    rating: 4.7,
    views: '185K',
    duration: '1h 45m',
    description: 'Mushiki w\'umukobwa utahura ibanga ribabaje ry\'umuryango we. Ibintu birakomera muri iyi film yahinduwe na Sankara.',
    isLatest: true,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    quality: 'HD 1080p',
    comments: [
      { id: '5', user: 'Divine_K', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80', text: 'Amasaha abiri ashize nyiyereka kuri Cineva app! Mwarakoze cyane.', time: '4 hours ago', likes: 12 }
    ]
  },
  {
    id: 'money-heist-agasobanuye',
    title: 'Money Heist (Agasobanuye)',
    originalTitle: 'La Casa de Papel',
    year: 2023,
    translatorId: 'kabosio',
    translatorName: 'VJ KABOSIO',
    category: 'Drama',
    type: 'Series',
    poster: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
    rating: 4.95,
    views: '340K',
    seasons: 5,
    episodesCount: 48,
    description: 'Professor n\'itsinda rye ry\'abajura bagaba igitero ku banki nkuru. VJ Kabosio asobanura icyiciro ku cyiciro n\'amatsiko atagira urugero.',
    isLatest: true,
    isFeatured: true,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    quality: 'HD 1080p',
    episodes: [
      { id: 'ep1', number: 1, title: 'Episode 1: Igitekerezo cya Professor', duration: '45m', thumbnail: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=400&q=80', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4' },
      { id: 'ep2', number: 2, title: 'Episode 2: Kwinjira mu Banki', duration: '48m', thumbnail: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=400&q=80', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyflights.mp4' },
      { id: 'ep3', number: 3, title: 'Episode 3: Umupolisi Raquel', duration: '50m', thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4' }
    ],
    comments: [
      { id: '6', user: 'Patrick_R', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&q=80', text: 'VJ Kabosio ni icyatwa! Episode zose nazirangije.', time: '1 day ago', likes: 67 }
    ]
  },
  {
    id: 'squid-game-dubbed',
    title: 'Squid Game (Kinyarwanda)',
    originalTitle: 'Squid Game Season 2',
    year: 2024,
    translatorId: 'junior',
    translatorName: 'VJ JUNIOR',
    category: 'Sci-Fi',
    type: 'Series',
    poster: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
    rating: 4.9,
    views: '290K',
    seasons: 2,
    episodesCount: 18,
    description: 'Imikino y\'ubuzima n\'urupfu ibamo amafaranga menshi. Junior Giti ayisobanura ashyiramo umwihariko uri mu rwego rwo hejuru.',
    isLatest: true,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
    quality: '4K Ultra',
    comments: []
  },
  {
    id: 'extraction-2',
    title: 'Extraction 2',
    originalTitle: 'Extraction II',
    year: 2023,
    translatorId: 'hakim',
    translatorName: 'HAKIM Prof',
    category: 'Action',
    type: 'Movie',
    poster: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1200&q=80',
    rating: 4.85,
    views: '195K',
    duration: '2h 02m',
    description: 'Tyler Rake agaruka mu gukora ubutumwa bukomeye bwo kurokora umuryango mu gereza ikomeye. Professor Hakim arabisobanura intambwe ku yindi.',
    isLatest: false,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutback2012.mp4',
    quality: 'HD 1080p',
    comments: []
  },
  {
    id: 'kingdom-war',
    title: 'Kingdom War',
    originalTitle: 'Dynasty Warriors',
    year: 2024,
    translatorId: 'gaheza',
    translatorName: 'GAHEZA',
    category: 'Action',
    type: 'Movie',
    poster: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80',
    banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
    rating: 4.5,
    views: '88K',
    duration: '1h 58m',
    description: 'Intambara z\'abami n\'ingabo z\'ibihangange. Gaheza atanga ubusobanuro bushimishije kuri buri mukino n\'inkota.',
    isLatest: true,
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    quality: 'HD 720p',
    comments: []
  }
];
